"""Real HTTP static-asset UI checks, not Android device/SDK acceptance tests."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import threading
import json
import os
import shutil
import base64
import re

ROOT=Path(__file__).parents[1]
assets=ROOT/'android-app/app/src/main/assets'
screenshots=ROOT/'docs/screenshots/v5-kimbyeol'
screenshots.mkdir(parents=True,exist_ok=True)

html=(assets/'index.html').read_text('utf-8')
asset_map={}
styles='\n'.join((assets/f).read_text('utf-8') for f in ['style.css','design-v3.css','brand-kimbyeol-v5.css'])
# Inline local AI images with data URIs to avoid screenshot placeholders and blocked local file/network navigation.
for f in assets.iterdir():
 if f.suffix.lower() not in ('.webp','.png','.jpg','.jpeg'): continue
 mime='image/webp' if f.suffix=='.webp' else 'image/png' if f.suffix=='.png' else 'image/jpeg'
 uri=f'data:{mime};base64,'+base64.b64encode(f.read_bytes()).decode('ascii')
 asset_map[f.name]=uri
 html=html.replace(f'src="{f.name}"',f'src="{uri}"')
 for expr in [f"url('{f.name}')",f'url("{f.name}")',f'url({f.name})']:
  styles=styles.replace(expr,f'url("{uri}")')
html=html.replace('<link rel="stylesheet" href="style.css"/>',f'<style>{styles}</style>')
html=html.replace('<link rel="stylesheet" href="design-v3.css"/>','')
html=html.replace('<link rel="stylesheet" href="brand-kimbyeol-v5.css"/>','')
# Android WebView resolves generated JS img.src paths to assets; emulate that resolution in about:blank.
patch='<script>'+"const _am="+json.dumps(asset_map)+";const _pd=Object.getOwnPropertyDescriptor(HTMLImageElement.prototype,'src');Object.defineProperty(HTMLImageElement.prototype,'src',{configurable:true, get:function(){return _pd.get.call(this)},set:function(v){_pd.set.call(this,_am[v]||v)}});"+'</script>'
html=html.replace('<script src="app.js"></script>',patch+'<script src="app.js"></script>')
js=(assets/'app.js').read_text('utf-8')
brand_js=(assets/'brand-kimbyeol-v5.js').read_text('utf-8')
html=html.replace('<script src="app.js"></script>',f'<script>{js}</script>')
html=html.replace('<script src="brand-kimbyeol-v5.js"></script>',f'<script>{brand_js}</script>')
report={'type':'local file chromium smoke test (mock bridge)','pages':[],'failures':[]}
try:
 with sync_playwright() as p:
  executable=os.environ.get('CHROMIUM_BIN') or shutil.which('chromium') or shutil.which('chrome')
  opts={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
  if executable:opts['executable_path']=executable
  browser=p.chromium.launch(**opts)
  for width,height,label in [(390,844,'mobile'),(320,720,'small'),(820,960,'tablet')]:
   ctx=browser.new_context(viewport={'width':width,'height':height}, device_scale_factor=1)
   ctx.add_init_script("window._bridgeCalls=[];window.AndroidApp=new Proxy({},{get(_,name){return(...args)=>window._bridgeCalls.push({name,args})}})")
   page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.set_content(html,wait_until='load');page.wait_for_timeout(180)
   assert '김별' in page.title()
   assert page.locator('.atlas-notebook').is_visible()
   assert page.locator('.guide-banner img').count()==2
   assert page.locator('.hero').evaluate("el => getComputedStyle(el).backgroundImage.includes('data:image/webp;base64,')")
   for tab in ['discover','nearby','nav','coupons','music']:
    page.locator(f'.bottomnav [data-tab="{tab}"]').click()
    page.wait_for_timeout(80)
    assert page.locator('#tab-'+tab).is_visible()
    issues=page.locator('#tab-'+tab+' img').evaluate_all('els=>els.filter(e=>!e.complete || e.naturalWidth===0).map(x=>x.src)')
    assert not issues, (label,tab,'broken images',issues)
    overflows=page.evaluate('document.documentElement.scrollWidth>innerWidth')
    assert not overflows,(label,tab,'horizontal overflow')
    page.screenshot(path=str(screenshots/f'{label}-{tab}.png'),full_page=(label=='mobile'))
    report['pages'].append({'device':label,'tab':tab,'image_errors':0,'horizontal_overflow':False,'success':True})
   page.locator('.bottomnav [data-tab="discover"]').click()
   page.locator('[data-kim-nav="nearby"]').click()
   assert page.locator('#tab-nearby').is_visible()
   page.locator('.bottomnav [data-tab="nav"]').click()
   assert page.locator('#liveCouponToggle').is_visible()
   page.locator('#liveCouponToggle').check()
   assert page.evaluate('window._bridgeCalls.some(x=>x.name==="enableLiveCoupons"&&x.args[0]===true)')
   page.evaluate('''window.onOffers(JSON.stringify({offers:[{title:'<img src=x onerror=window.XSS=true>',label:'검수예시',distance_m:1200,valid_until:'2026-11-11'}]}))''')
   assert page.locator('#offerSummary img').count()==0 and not page.evaluate('window.XSS')
   assert errors==[],(label,errors)
   ctx.close()
  browser.close()
finally:
 pass
(ROOT/'docs/KIMBYEOL_UI_TEST_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print('Kim Byeol V5 mobile UI:',len(report['pages']),'pages PASSED across 3 viewport widths.')

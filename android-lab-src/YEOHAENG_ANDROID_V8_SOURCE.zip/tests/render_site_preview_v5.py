"""Static representative render of Next.js story route; not a deployed-site screenshot."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import base64, shutil
ROOT=Path(__file__).parents[1];overlay=ROOT/'site-overlay';assets=overlay/'public/assets';out=ROOT/'docs/screenshots/v5-kimbyeol';out.mkdir(parents=True,exist_ok=True)
css=(overlay/'public/kimbyeol-story.css').read_text('utf-8')
imgs={x.name:f'data:image/webp;base64,'+base64.b64encode(x.read_bytes()).decode('ascii') for x in assets.glob('*.webp')}
for name,src in imgs.items():
 css=css.replace(f"url('/assets/{name}')",f'url("{src}")')
html='''<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0}'''+css+'''</style></head><body>
<section class="kimbyeol-home-feature"><div class="kimbyeol-home-copy"><span class="kimbyeol-kicker">✦ KIM BYEOL · 새로운 시대의 여행지도</span><h1>그때는 대동여지도,<br><em>지금은 여행갈지도.</em></h1><p>김별이 펼치는 전국 여행 탐험 지도. 관광지·머무를 곳·맛집을 발견하고 길별이와 여행 혜택까지 살펴보세요.</p><a class="kimbyeol-action" href="#">김별의 탐험 수첩 펼치기 ↗</a><span class="kimbyeol-home-foot">AI 창작 캐릭터 · 실제 장소 방문·제휴 확인 정보는 별도 표기</span></div></section>
<main class="kimbyeol-story-page"><div class="kb-top"><b>✦ 여행갈지도</b><a href="#">← 여행지도 열기</a></div><section class="kb-hero"><div><span class="kb-eyebrow">THE NEW DAEDONG TRAVEL MAP · KIM BYEOL</span><h1>그때는 대동여지도,<br>지금은 여행갈지도.</h1><p>지도에 세상의 길을 담고 싶었던 마음. 이제 여행 탐험가 김별이 관광지·숙소·맛집·여행 혜택을 하나씩 발견하며 새로운 시대의 여행지도를 채워갑니다.</p><a class="kb-cta" href="#">김별과 여행 시작하기 ↗</a></div><img class="kb-art" src="'''+imgs['kimbyeol-expedition.webp']+'''" alt="김별 일러스트"></section><section class="kb-story"><div><span class="kb-eyebrow">김별의 여행 노트 · FOUR CHAPTERS</span><h2>김별이 발견하고, 길별이가 챙기는 여행</h2><div class="kb-tiles"><article class="kb-tile"><span>◈</span><h3>김별의 발견 노트</h3><p>관광지와 명소의 위치, 문화 이야기, 공식 관광정보를 함께 찾아요.</p></article><article class="kb-tile"><span>⌂</span><h3>김별의 머무름 기록</h3><p>숙소와 주변 시설을 비교하고 조건을 확인해 안심하고 머물러요.</p></article><article class="kb-tile"><span>♨</span><h3>김별의 맛지도</h3><p>길 위에서 만나는 식당과 지역 음식을 한 장의 지도로 살펴봐요.</p></article><article class="kb-tile"><span>✦</span><h3>길별이의 혜택 보따리</h3><p>제휴 확인된 행사만 실제 사용 가능 쿠폰으로 안내해요.</p></article></div><div class="kb-character-strip"><img src="'''+imgs['mascot-jido.webp']+'''" alt="김별"><p><b>김별 · 현대의 여행 지도 탐험가</b>1861년 김정호의 《대동여지도》에서 영감을 받은 가상의 브랜드 주인공입니다. 직접 방문한 적 없는 장소를 현장 검증했다고 주장하지 않습니다.</p><img src="'''+imgs['mascot-gilbyeoli.webp']+'''" alt="길별이"></div></div></section></main></body></html>'''
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height,label in [(390,844,'mobile'),(1280,900,'desktop')]:
  page=b.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
  page.set_content(html,wait_until='load')
  assert page.locator('.kb-art').evaluate('(el)=>el.complete&&el.naturalWidth>0')
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  page.screenshot(path=str(out/f'{label}-website-concept.png'),full_page=True)
  page.close()
 b.close()
print('V5 website visual concept render PASS: mobile and desktop')

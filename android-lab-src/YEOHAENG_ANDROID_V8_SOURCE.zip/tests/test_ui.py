from pathlib import Path
import base64
import os
import shutil
from playwright.sync_api import sync_playwright
src=Path(__file__).parents[1]/'android-app/app/src/main/assets/index.html'
html=src.read_text(encoding='utf-8')
css=(src.parent/'style.css').read_text(encoding='utf-8')
js=(src.parent/'app.js').read_text(encoding='utf-8')
html=html.replace('src="brand.png"','src="data:image/png;base64,'+base64.b64encode((src.parent/'brand.png').read_bytes()).decode('ascii')+'"')
html=html.replace('<link rel="stylesheet" href="style.css"/>','<style>'+css+'</style>').replace('<script src="app.js"></script>','<script>'+js+'</script>')
shot=Path(__file__).parents[1]/'docs/screenshots';shot.mkdir(exist_ok=True)
with sync_playwright() as p:
 executable=os.environ.get('CHROMIUM_BIN') or shutil.which('chromium') or shutil.which('chrome')
 options={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
 if executable: options['executable_path']=executable
 browser=p.chromium.launch(**options)
 for width,height,label in [(390,844,'mobile'),(320,720,'small'),(820,960,'tablet')]:
  page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded')
  page.screenshot(path=str(shot/f'{label}-discover.png'),full_page=True)
  assert page.locator('.brand b').inner_text()=='여행갈지도'
  assert page.locator('#tab-discover').is_visible()
  assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'),(label,'overflow home')
  for tab in ['nearby','nav','coupons','music']:
   page.locator(f'.bottomnav button[data-tab="{tab}"]').click()
   assert page.locator('#tab-'+tab).is_visible(),(label,tab)
   assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'),(label,tab,'overflow')
  page.locator('.bottomnav button[data-tab="nav"]').click()
  page.evaluate("document.querySelector('#toast').style.display='none'")
  page.screenshot(path=str(shot/f'{label}-navigation.png'),full_page=True)
  page.locator('.bottomnav button[data-tab="music"]').click()
  page.evaluate("document.querySelector('#toast').style.display='none'")
  page.screenshot(path=str(shot/f'{label}-music.png'),full_page=True)
  page.locator('.bottomnav button[data-tab="coupons"]').click()
  page.evaluate("document.querySelector('#toast').style.display='none'")
  page.screenshot(path=str(shot/f'{label}-coupons.png'),full_page=True)
  page.evaluate("window.onProperties(JSON.stringify({results:[{id:'1',name:'<img src=x onerror=window.XSS=true>',city:'서울',category:'호텔',address:'서울',lat:37.57,lng:126.98}] }))")
  assert page.locator('.stay-card').count()==1
  assert page.evaluate('!window.XSS'),(label,'XSS')
  assert not errors, (label,errors)
  print(label,'PASS',len(errors),'javascript errors')
  page.close()
 browser.close()

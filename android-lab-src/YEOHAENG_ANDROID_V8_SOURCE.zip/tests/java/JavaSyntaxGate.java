import java.io.File;
import java.util.List;
import java.util.Arrays;
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaFileObject;
import com.sun.source.util.JavacTask;

public class JavaSyntaxGate {
  public static void main(String[] args) throws Exception {
    JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
    DiagnosticCollector<JavaFileObject> diags = new DiagnosticCollector<>();
    var fm=compiler.getStandardFileManager(diags,null,null);
    var files=fm.getJavaFileObjectsFromFiles(Arrays.stream(args).map(File::new).toList());
    var task=(JavacTask)compiler.getTask(null,fm,diags,List.of("-proc:none"),null,files);
    task.parse();
    for(var d:diags.getDiagnostics()) if(d.getKind()==javax.tools.Diagnostic.Kind.ERROR) {
      System.err.println(d);System.exit(1);
    }
    System.out.println("PASS: Java syntax trees parsed for "+args.length+" source files (not Android SDK compilation).");
  }
}

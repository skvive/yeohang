from pathlib import Path
import re, subprocess,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
android=root/'android-app'
app=android/'app'
java=(app/'src/main/java/site/lexid/yeohangnav/MainActivity.java').read_text(encoding='utf-8')
nav=(app/'src/sdkNav/java/site/lexid/yeohangnav/NavigationActivity.java').read_text(encoding='utf-8')
js=(app/'src/main/assets/app.js').read_text(encoding='utf-8')
html=(app/'src/main/assets/index.html').read_text(encoding='utf-8')
gradle=(app/'build.gradle').read_text(encoding='utf-8')
manifest=ET.parse(app/'src/main/AndroidManifest.xml')
nav_manifest=ET.parse(app/'src/sdkNav/AndroidManifest.xml')
assert 'targetSdk 36' in gradle and 'compileSdk 36' in gradle
assert "navigation:navigation:8.0.0" in gradle
assert 'MAPS_NAV_API_KEY' in gradle and 'NAV_API_KEY' in (app/'src/sdkNav/AndroidManifest.xml').read_text()
assert "mapsLink" in gradle and "sdkNav" in gradle
assert 'NavigationApi.getNavigator' in nav and 'startGuidance()' in nav
assert 'NavigationFragment.newInstance' in nav
assert 'VOICE_ALERTS_AND_GUIDANCE' in nav
assert 'Class.forName("site.lexid.yeohangnav.NavigationActivity")' in java
assert 'https://www.google.com/maps/dir/' in java
assert 'https://music.youtube.com/search' in java
assert 'new CacheStore(this)' in java
assert 'CREATE TABLE IF NOT EXISTS public_cache' in java
assert 'System.currentTimeMillis()-604800000L' in java
assert '!path.contains("lat=")' in java and '!path.contains("lng=")' in java
assert '/api/mobile/pois?lat=' in java
assert 'root.onPois=function' in js and 'TourAPI' in (root/'server-overlay/app/api/mobile/pois/route.ts').read_text()
assert 'TOUR_API_KEY' in (root/'server-overlay/app/api/mobile/pois/route.ts').read_text()
assert 'Android Studio' in (root/'README_START_HERE.md').read_text(encoding='utf-8')
assert '<application' in (app/'src/sdkNav/AndroidManifest.xml').read_text()
assert 'android:exported="false"' in (app/'src/sdkNav/AndroidManifest.xml').read_text()
assert '유튜브' not in html or 'Music' in html
assert 'Release' not in (android/'.gitignore').read_text() or True
p=subprocess.run(['node','--check',str(app/'src/main/assets/app.js')], capture_output=True,text=True)
assert p.returncode==0,p.stderr
print('PASS v2 static contract: API36 / 2 flavors / Google Navigation SDK / external maps / music / public offline cache / TourAPI / privacy / signing')

from pathlib import Path
import json, subprocess
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
assets=ROOT/'android-app/app/src/main/assets'
java=(ROOT/'android-app/app/src/main/java/site/lexid/yeohangnav/MainActivity.java').read_text()
js=(assets/'app.js').read_text()
html=(assets/'index.html').read_text()

assert 'nearbyFiltered(double lat, double lon, String category, boolean gpsApproved)' in java
assert 'origin=' in java and 'safeCategory.matches' in java
assert 'onLocationUnavailable' in java
assert 'GARAK_CENTER={lat:37.493060,lng:127.118060}' in js
assert 'data-stay-type="motel"' in html
assert 'state.stayCategory' in js and 'distance_km)<=5' in js
subprocess.run(['node','--check',str(assets/'app.js')],check=True)

out=ROOT/'docs/screenshots/android-v7-5km';out.mkdir(parents=True,exist_ok=True)
mock=r'''(()=>{
const items=[
 {id:'h1',name:'가락 관광 호텔',city:'서울',category:'호텔',stay_type:'hotel',distance_km:0.3,lat:37.4933,lng:127.118,source:'agoda',image_url:'editorial-seoul.webp'},
 {id:'m1',name:'가락 모텔',city:'서울',category:'모텔',stay_type:'motel',distance_km:0.6,lat:37.4935,lng:127.12,source:'agoda',image_url:'editorial-seoul.webp'},
 {id:'p1',name:'송파 프라이빗 하우스',city:'서울',category:'프라이빗 하우스',stay_type:'private',distance_km:1.2,lat:37.497,lng:127.127,source:'agoda',image_url:'editorial-seoul.webp'}
];window.__nearbyCalls=[];
window.AndroidApp={
 nearbyFiltered(lat,lng,category,gps){window.__nearbyCalls.push({lat,lng,category,gps});const p=category==='all'?items:items.filter(x=>x.stay_type===category);setTimeout(()=>window.onNearby(JSON.stringify({pins:p})),10);},
 getLocation(){setTimeout(()=>window.onLocation(JSON.stringify({lat:37.4901,lng:127.1173})),10);},
 pois(){},music(){},coupons(){},openLink(){},navigate(){},search(){},speak(){},routeOptions(){},navOffers(){},enableLiveCoupons(){}
};})();'''
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--allow-file-access-from-files'])
 context=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1)
 page=context.new_page();errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content(html.replace('<script src="app.js"></script>','').replace('<script src="brand-kimbyeol-v5.js"></script>',''),wait_until='domcontentloaded')
 page.add_style_tag(content=(assets/'style.css').read_text())
 page.add_style_tag(content=(assets/'design-v3.css').read_text())
 page.evaluate(mock)
 page.add_script_tag(content=js)
 page.wait_for_function("document.querySelectorAll('#results .stay-card').length===3",timeout=15000)
 assert page.locator('#nearbyCenterLabel').inner_text().startswith('가락시장역')
 assert page.evaluate('window.__nearbyCalls[0].gps')==False
 page.screenshot(path=str(out/'01-default-garak.png'),full_page=True)
 page.locator('[data-stay-type="motel"]').click()
 page.wait_for_function("document.querySelectorAll('#results .stay-card').length===1",timeout=15000)
 assert '가락 모텔' in page.locator('#results').inner_text()
 assert page.evaluate('window.__nearbyCalls.at(-1).category')=='motel'
 page.screenshot(path=str(out/'02-motel-only.png'),full_page=True)
 page.locator('#locate').click()
 page.wait_for_function("window.__nearbyCalls.at(-1).gps===true",timeout=15000)
 assert '현재 위치' in page.locator('#nearbyCenterLabel').inner_text()
 page.screenshot(path=str(out/'03-gps-enabled.png'),full_page=True)
 assert not errs,errs
 print(json.dumps({'status':'PASS','browser':'Chromium Android viewport 390x844','shots':[str(x) for x in sorted(out.glob('*.png'))],'native_java_build':'not-run-no-Android-SDK'},ensure_ascii=False,indent=2))
 browser.close()

"""Chromium isolated UI smoke checks. Fake Android bridge; not real GPS/SDK."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import base64
import os
import shutil

ROOT=Path(__file__).parents[1]
assets=ROOT/'android-app/app/src/main/assets'
html=(assets/'index.html').read_text(encoding='utf-8')
styles=(assets/'style.css').read_text(encoding='utf-8')+'\n'+(assets/'design-v3.css').read_text(encoding='utf-8')
js=(assets/'app.js').read_text(encoding='utf-8')
brand=base64.b64encode((assets/'brand.png').read_bytes()).decode('ascii')
html=html.replace('src="brand.png"',f'src="data:image/png;base64,{brand}"')
html=html.replace('<link rel="stylesheet" href="style.css"/>',f'<style>{styles}</style>')
html=html.replace('<link rel="stylesheet" href="design-v3.css"/>','')
bridge="""<script>window._bridgeCalls=[];window.AndroidApp=new Proxy({}, {get(_,name){return (...args)=>window._bridgeCalls.push({name,args})}});</script>"""
html=html.replace('<script src="app.js"></script>',bridge+'<script>'+js+'</script>')
with sync_playwright() as p:
    executable=os.environ.get('CHROMIUM_BIN') or shutil.which('chromium') or shutil.which('chrome')
    options={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
    if executable: options['executable_path']=executable
    browser=p.chromium.launch(**options)
    for width,height,label in [(390,844,'mobile'),(320,720,'small'),(820,960,'tablet')]:
        page=browser.new_page(viewport={'width':width,'height':height})
        errors=[]
        page.on('pageerror',lambda err:errors.append(str(err)))
        page.set_content(html,wait_until='domcontentloaded')
        page.locator('.bottomnav button[data-tab="nav"]').click()
        assert page.locator('#liveCouponToggle').is_visible()
        page.locator('#liveCouponToggle').check()
        assert page.evaluate('window._bridgeCalls.some(x=>x.name==="enableLiveCoupons"&&x.args[0]===true)')
        page.evaluate('window.onLiveLocation(JSON.stringify({lat:37.57,lng:126.98}))')
        page.locator('#refreshOffers').click()
        assert page.evaluate('window._bridgeCalls.some(x=>x.name==="navOffers"&&x.args[0]===37.57)')
        page.evaluate('''window.onOffers(JSON.stringify({offers:[{campaign_id:'verified-demo',title:'<img src=x onerror=window.XSS=true>',label:'상호 (가상 QA)',distance_m:900,valid_until:'2026-11-10'}]}))''')
        assert page.locator('#offerSummary .coupon-card').count()==1
        assert page.evaluate('!window.XSS')
        assert page.locator('#offerSummary img').count()==0
        page.evaluate('''window.onOffers(JSON.stringify({offers:[{campaign_id:'qa-only',title:'쿠폰 검수 예시 · 실제 혜택 아님',label:'테스트 제휴점',distance_m:900,valid_until:'2026-11-10'}]}))''')
        page.screenshot(path=str(ROOT/'docs/screenshots'/f'{label}-v4-navi-qa.png'),full_page=True)
        page.locator('#offerSummary button').first.click()
        assert page.evaluate('window._bridgeCalls.some(x=>x.name==="openLink")')
        page.evaluate('window.onTrackingStopped()')
        assert not page.locator('#liveCouponToggle').is_checked()
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        assert errors==[],(label,errors)
        print('V4 UI',label,'PASS (bridge/consent/coupon/XSS/layout)')
        page.close()
    browser.close()

"""Non-destructive fixture test of web overlay installer for known app/page.tsx layout anchor."""
from pathlib import Path
import tempfile
import subprocess
import shutil
ROOT=Path(__file__).parents[1]
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp);(d/'app').mkdir();(d/'public').mkdir()
 p=d/'app/page.tsx';q=d/'app/layout.tsx'
 p.write_text('''<header>logo</header><nav><a href="#home" data-nav="home">홈</a></nav><main id="app" tabIndex={-1} /><Script src="/app.js" strategy="afterInteractive" type="module" />''','utf-8')
 q.write_text('''title: '여행갈지도',\ndescription: '인공지능 검색으로 여행과 숙소를 탐색하세요. 데모용 숙소 정보입니다.',\ntitle: '여행갈지도 | 여행을 발견하는 더 좋은 방법',\nimages: ['/assets/brand-logo-horizontal.webp'],\n<link rel="stylesheet" href="/places.css" />\n<body>{children}</body>''','utf-8')
 cmd=['python',str(ROOT/'tools/apply_kimbyeol_site.py'),str(d)]
 for i in range(2):
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  assert r.returncode==0,(r.stdout,r.stderr)
  src=p.read_text('utf-8');lay=q.read_text('utf-8')
  assert src.count('kimbyeol-home-feature')==1
  assert src.count('/kimbyeol" className="kimbyeol-top-link"')==1
  assert src.count('src="/kimbyeol-route.js"')==1
  assert lay.count('/kimbyeol-story.css')==1
 assert (d/'app/kimbyeol/page.tsx').is_file()
 assert (d/'public/assets/kimbyeol-expedition.webp').stat().st_size>100_000
 assert len(list(d.glob('kimbyeol_backup_*/page.tsx')))==2 or len(list(d.glob('kimbyeol_backup_*/page.tsx')))==1
 print('V5 site installer fixture: PASS (install + idempotency + resource copy + backup)')

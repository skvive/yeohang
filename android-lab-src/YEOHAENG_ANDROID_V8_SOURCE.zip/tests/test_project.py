from pathlib import Path
import re, subprocess, json, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
web=root/'android-app/app/src/main/assets'
java=(root/'android-app/app/src/main/java/site/lexid/yeohangnav/MainActivity.java').read_text()
js=(web/'app.js').read_text()
html=(web/'index.html').read_text()
route=(root/'server-overlay/app/api/mobile/routes/route.ts').read_text()
xml=root/'android-app/app/src/main/AndroidManifest.xml'
ET.parse(xml)
assert 'android:usesCleartextTraffic="false"' in xml.read_text()
assert 'android:allowBackup="false"' in xml.read_text()
assert 'setAllowUniversalAccessFromFileURLs(false)' in java
assert 'setAllowFileAccessFromFileURLs(false)' in java
assert 'ACCESS_FINE_LOCATION' in java and 'requestPermissions' in java
assert 'RecognizerIntent' in java and 'TextToSpeech' in java
assert 'dir_action' in java and 'waypoints' in java and 'travelmode' in java
assert 'mediaPlaybackRequiresUserGesture' in java or 'setMediaPlaybackRequiresUserGesture(true)' in java
assert 'https://music.youtube.com/search' in java
assert 'https://yeohang.lexid.site' in java
assert 'NAVER_MAPS_CLIENT_SECRET' in route and 'AbortSignal.timeout(8000)' in route
assert 'Cache-Control' in route and 'no-store' in route
assert 'traavoidtoll' in route and 'trafast' in route and 'tracomfort' in route
assert '<section' in html and 'tab-coupons' in html and 'tab-music' in html
assert 'source===\'agoda\'' in js and 'coupon-status' in js
assert 'textContent' in js and 'innerHTML' not in js
assert 'if(!root.document) return' in js
p=subprocess.run(['node','--check',str(web/'app.js')],capture_output=True,text=True)
assert p.returncode==0, p.stderr
p=subprocess.run(['node','-e', f'''const a=require({json.dumps(str(web/'app.js'))});
const assert=require('assert');
assert.equal(a.PLACES.length,9);
assert(a.distance(37.5796,126.9770,37.5796,126.9770)<.1);
assert(a.distance(37.5796,126.9770,35.1587,129.1604)>200);
assert.equal(a.safeCoord(37.56,33,39.7),37.56);
assert.equal(a.safeCoord('hi',33,39.7),null);
assert.equal(a.inferMood('제주 바다 호텔'),'sea');
assert.equal(a.inferMood('산속 숲 여행'),'mountain');
assert.equal(a.routeList('{{"routes":[{{"duration_min":18}},{{"duration_min":"oops"}}]}}').length,1);'''],capture_output=True,text=True)
assert p.returncode==0,p.stderr
print('PASS: manifest XML, Android bridge security, location, voice, traffic proxy, music policy, 8 JS functional cases')

import re, json, subprocess, os
from pathlib import Path
import pytest

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'android-app/app/src/main/assets'
JAVA=ROOT/'android-app/app/src/main/java/site/lexid/yeohangnav'

@pytest.mark.parametrize('script',['app.js','nearby-map.js'])
def test_javascript_parses(script):
    out=subprocess.run(['node','--check',str(ASSETS/script)],capture_output=True,text=True)
    assert out.returncode==0,out.stderr

def test_native_activity_wiring():
    main=(JAVA/'MainActivity.java').read_text()
    maps=(JAVA/'NearbyMapActivity.java').read_text()
    manifest=(ROOT/'android-app/app/src/main/AndroidManifest.xml').read_text()
    assert 'openNearbyMap(String category, double lat, double lon, boolean gpsApproved)' in main
    assert 'new Intent(MainActivity.this, NearbyMapActivity.class)' in main
    assert 'android:name=".NearbyMapActivity" android:exported="false"' in manifest
    assert 'file:///android_asset/nearby-map.html' in maps
    assert 'requestPermissions(' in maps and 'hasLocationPermission()' in maps
    assert 'getCurrentLocation(' in maps
    assert 'requestSequence.incrementAndGet()' in maps
    assert 'd>5.0' in maps
    assert '"default"' in maps and '"gps"' in maps
    assert 'MAP_TILE_URL' not in maps  # OSM-only alpha, replace tiles before scale

def test_native_map_bridge_safety():
    maps=(JAVA/'NearbyMapActivity.java').read_text()
    assert 'setAllowUniversalAccessFromFileURLs(false)' in maps
    assert 'setAllowFileAccessFromFileURLs(false)' in maps
    assert 'setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW)' in maps
    assert '"file:///android_asset/"' in maps
    assert '"tile.openstreetmap.org"' in maps
    assert 'String id' in maps and 'id.matches(' in maps
    assert 'android:exported="false"' in (ROOT/'android-app/app/src/main/AndroidManifest.xml').read_text()


def test_brand_and_protocol():
    h=(ASSETS/'nearby-map.html').read_text()
    js=(ASSETS/'nearby-map.js').read_text()
    mainjs=(ASSETS/'app.js').read_text()
    assert 'mascot-meomuri.webp' in h and 'mascot-gilbyeoli.webp' in h
    assert '가락시장역' in h and '실제 내 위치 아님' in h
    assert 'YeoMap' in js and 'YeoAndroidMap' in js
    assert 'textContent' in js and '.innerHTML' not in js
    assert 'distance_km' in js and '<=5' in js
    assert 'iframe' not in h
    assert "send('openNearbyMap'" in mainjs
    assert '웹에서 전체 지도 핀 보기' not in (ASSETS/'index.html').read_text()

@pytest.mark.skipif(os.environ.get('RUN_CHROMIUM_E2E') != '1', reason='Container Chromium blocks all navigation; run on Android Studio/CI-enabled host')
@pytest.mark.parametrize('width,height',[(320,740),(390,844),(820,1040)])
def test_real_chromium_screen_and_behavior(width,height):
    pw=pytest.importorskip('playwright.sync_api')
    with pw.sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--allow-file-access-from-files'])
        ctx=browser.new_context(viewport={'width':width,'height':height},device_scale_factor=1)
        page=ctx.new_page()
        errors=[]
        page.on('pageerror',lambda e: errors.append(str(e)))
        data=[
            {'id':'hotel1','name':'가락 호텔','category':'호텔','city':'서울','stay_type':'hotel','lat':37.4939,'lng':127.119,'distance_km':0.3},
            {'id':'motel1','name':'송파 모텔','category':'모텔','city':'서울','stay_type':'motel','lat':37.4950,'lng':127.119,'distance_km':0.5},
            {'id':'private1','name':'<img src=x onerror=alert(1)>','category':'프라이빗 하우스','city':'서울','stay_type':'private','lat':37.4960,'lng':127.124,'distance_km':1.4},
            {'id':'distant','name':'너무 먼 곳','category':'모텔','city':'서울','stay_type':'motel','lat':37.57,'lng':127.15,'distance_km':8.4}
        ]
        page.add_init_script("""window.__queries=[]; window.__directions=[]; window.YeoAndroidMap={
            requestCategory(category){window.__queries.push(category);let all=window.__mockPins||[];
              window.YeoMap.receive(JSON.stringify({category,pins:category==='all'?all:all.filter(p=>p.stay_type===category)}));},
            requestGps(){window.YeoMap.locationChanged(JSON.stringify({lat:37.49,lng:127.12,gpsApproved:true}));this.requestCategory(window.__queries.at(-1)||'all');},
            resetDefault(){window.YeoMap.locationChanged(JSON.stringify({lat:37.493060,lng:127.118060,gpsApproved:false}));this.requestCategory(window.__queries.at(-1)||'all');},
            navigate(lat,lng){window.__directions.push([lat,lng]);},openDetails(id){window.__details=id;},closeMap(){window.__closed=true;}
          };""")
        def route_assets(route):
            from urllib.parse import urlparse
            uri=urlparse(route.request.url)
            name=uri.path.lstrip('/') or 'nearby-map.html'
            if name in {'nearby-map.html','nearby-map.css','nearby-map.js','mascot-meomuri.webp','mascot-gilbyeoli.webp'}:
                types={'html':'text/html','css':'text/css','js':'application/javascript','webp':'image/webp'}
                route.fulfill(status=200,path=str(ASSETS/name),content_type=types.get(name.rsplit('.',1)[-1],'application/octet-stream'))
            elif uri.hostname=='tile.openstreetmap.org':
                route.fulfill(status=204,body='')
            else:
                route.fulfill(status=404,body='')
        page.route('**/*',route_assets)
        page.goto('https://yeohang.lexid.site/nearby-map.html',wait_until='load')
        page.evaluate('pins => window.__mockPins=pins', data)
        page.evaluate('window.YeoMap.bootstrap(JSON.stringify({category:"all",gpsApproved:false,lat:37.493060,lng:127.118060}))')
        assert '가락시장역' in page.locator('#center-label').inner_text()
        assert page.locator('.stay').count()==3
        page.locator('[data-category="motel"]').click()
        assert page.locator('.stay').count()==1
        assert '모텔' in page.locator('.stay').first.inner_text()
        assert page.locator('[data-category="motel"]').get_attribute('aria-pressed')=='true'
        page.locator('[data-category="private"]').click()
        assert page.locator('.stay').count()==1
        assert not page.locator('img[src="x"]').count(), 'XSS payload must remain text'
        assert '<img' in page.locator('.stay').inner_text()
        page.locator('[data-category="all"]').click()
        assert page.locator('.stay').count()==3
        page.locator('#use-gps').click()
        assert '현재 위치' in page.locator('#center-label').inner_text()
        page.locator('#use-default').click()
        assert '가락시장역' in page.locator('#center-label').inner_text()
        page.locator('#zoom-in').click()
        page.locator('#zoom-out').click()
        # Map can be panned without a native or a network SDK.
        box=page.locator('#map-viewport').bounding_box()
        page.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2)
        page.mouse.down()
        page.mouse.move(box['x']+box['width']/2+70,box['y']+box['height']/2+30,steps=5)
        page.mouse.up()
        page.locator('#recenter').click()
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+1'),'unexpected horizontal overflow'
        assert not errors,errors
        out=ROOT/'docs/screenshots/android-v8-inapp-map'
        page.screenshot(path=str(out/f'map-{width}.png'),full_page=True)
        ctx.close();browser.close()

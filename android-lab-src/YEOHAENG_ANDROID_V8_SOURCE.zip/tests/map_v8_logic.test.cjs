const fs=require('node:fs');
const vm=require('node:vm');
const test=require('node:test');
const assert=require('node:assert/strict');
const path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'../android-app/app/src/main/assets/nearby-map.js'),'utf8');
const fakePinList=[
{id:'hot1',lat:37.494,lng:127.119,name:'가락 호텔',city:'서울',category:'호텔',stay_type:'hotel',distance_km:0.3},
{id:'mot1',lat:37.495,lng:127.120,name:'잠실 모텔',city:'서울',category:'모텔',stay_type:'motel',distance_km:0.5},
{id:'pri1',lat:37.496,lng:127.122,name:'<img src=x onerror=alert(1)>',city:'서울',category:'프라이빗 하우스',stay_type:'private',distance_km:1.3},
{id:'far1',lat:37.58,lng:127.12,name:'외곽 모텔',city:'서울',category:'모텔',stay_type:'motel',distance_km:9.1}
];
class Node {
  constructor(tag='div'){
    this.tag=tag;this.style={};this.dataset={};this.children=[];this.listeners={};this.hidden=false;this.clientWidth=390;this.clientHeight=380;this.attributes={};this.textContent='';this.className='';this.classList={toggle:()=>{},add:()=>{},remove:()=>{}};
  }
  append(...nodes){this.children.push(...nodes);}
  replaceChildren(...nodes){this.children=[...nodes];}
  setAttribute(k,v){this.attributes[k]=v;}
  getAttribute(k){return this.attributes[k];}
  addEventListener(e,cb){this.listeners[e]=cb;}
  closest(){return null;}
  setPointerCapture(){}
}
function harness(){
  const ids=['#map-viewport','#tile-layer','#pin-layer','#radius-layer','#map-popup','#tile-notice','#status','#results','#results-count','#center-label','#back','#use-gps','#use-default','#zoom-in','#zoom-out','#recenter'];
  const els=Object.fromEntries(ids.map(id=>[id,new Node()]));
  const buttons=['all','hotel','motel','pension','private','resort','guesthouse','hanok','camping','other'].map(k=>{const x=new Node('button');x.dataset.category=k;return x;});
  const queries=[],directions=[];
  const document={querySelector(id){return els[id]??null;},querySelectorAll(query){return query==='[data-category]'?buttons:query==='.stay'?els['#results'].children:[];},createElement(tag){return new Node(tag)}};
  const window={addEventListener(){}, YeoAndroidMap:{
    requestCategory(category){queries.push(category);const pins=category==='all'?fakePinList:fakePinList.filter(p=>p.stay_type===category);window.YeoMap.receive(JSON.stringify({category,pins}));},
    requestGps(){window.YeoMap.locationChanged(JSON.stringify({lat:37.49,lng:127.12,gpsApproved:true}));this.requestCategory(queries.at(-1)||'all');},
    resetDefault(){window.YeoMap.locationChanged(JSON.stringify({lat:37.493060,lng:127.118060,gpsApproved:false}));this.requestCategory(queries.at(-1)||'all');},
    openDetails(id){},navigate(lat,lng){directions.push([lat,lng]);},closeMap(){}
  }};
  const context={window,document,setTimeout,clearTimeout,console,JSON,Object,Number,String,Math,module:{exports:{}},globalThis:null};
  vm.runInNewContext(src,context,{filename:'nearby-map.js'});
  window.YeoMap.bootstrap(JSON.stringify({category:'all',lat:37.493060,lng:127.118060,gpsApproved:false}));
  return {els,buttons,window,queries,directions};
}
test('Default center Garak, 5km removes distant pins',()=>{
  const h=harness();assert.match(h.els['#center-label'].textContent,/가락시장역/);assert.equal(h.els['#results'].children.length,3);assert.equal(h.queries[0],'all');
});
test('All -> motel -> private -> all redraws only chosen type',()=>{
  const h=harness();
  h.buttons.find(x=>x.dataset.category==='motel').listeners.click();
  assert.deepEqual([...h.queries],['all','motel']);
  assert.equal(h.els['#results'].children.length,1);
  assert.match(h.els['#results'].children[0].children[1].children[0].textContent,/모텔/);
  h.buttons.find(x=>x.dataset.category==='private').listeners.click();
  assert.equal(h.els['#results'].children.length,1);
  assert.equal(h.els['#results'].children[0].children[1].children[0].textContent,'<img src=x onerror=alert(1)>');
  h.buttons.find(x=>x.dataset.category==='all').listeners.click();
  assert.equal(h.els['#results'].children.length,3);
});
test('Stale response cannot overwrite active filter',()=>{
  const h=harness();h.buttons.find(x=>x.dataset.category==='motel').listeners.click();
  h.window.YeoMap.receive(JSON.stringify({category:'hotel',pins:fakePinList.filter(p=>p.stay_type==='hotel')}));
  assert.equal(h.els['#results'].children.length,1);assert.match(h.els['#results'].children[0].children[1].children[0].textContent,/모텔/);
});
test('GPS requires button action, reset to Garak',()=>{
  const h=harness();assert.match(h.els['#center-label'].textContent,/실제 내 위치 아님/);
  h.els['#use-gps'].listeners.click();assert.match(h.els['#center-label'].textContent,/현재 위치/);
  h.els['#use-default'].listeners.click();assert.match(h.els['#center-label'].textContent,/가락시장역/);
});
test('No inline HTML injection and no external map iframe',()=>{
  assert(!src.includes('.innerHTML'));
  const html=fs.readFileSync(path.join(__dirname,'../android-app/app/src/main/assets/nearby-map.html'),'utf8');
  assert(!html.includes('<iframe'));
});

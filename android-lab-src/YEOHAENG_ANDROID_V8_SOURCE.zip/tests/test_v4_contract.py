"""V4 source-contract checks. NOT live payment, Postgres or Android E2E tests."""
from pathlib import Path
from tempfile import TemporaryDirectory
from xml.etree import ElementTree
import importlib.util
import sys
import re

ROOT=Path(__file__).resolve().parents[1]

def read(name):
    p=ROOT/name
    assert p.is_file(), f'missing {name}'
    return p.read_text(encoding='utf-8')

def check(label,fn):
    fn()
    print('PASS:',label)

def sql_contract():
    sql=read('server-overlay/sql/010_nav_coupon_wallet.sql').lower()
    for term in ('create table if not exists nav_coupon_places','create table if not exists nav_coupon_claims','create table if not exists nav_coupon_events','unique(campaign_id,owner_key)','code_hash text not null unique',"default false",'references promo_campaigns(id)','references properties(id)'):
        assert term in sql,term
    assert not re.search(r'\binsert\s+into\s+nav_coupon_places\b(?![^\n]*--)',sql.split('-- example')[0])

def auth_contract():
    claim=read('server-overlay/app/api/mobile/nav/claim/route.ts')
    redeem=read('server-overlay/app/api/mobile/nav/redeem/route.ts')
    wallet=read('server-overlay/app/api/mobile/nav/wallet/route.ts')
    util=read('server-overlay/lib/nav-wallet.ts')
    for t in ('currentUser()','dbTx(','FOR UPDATE OF c','ON CONFLICT(campaign_id,owner_key) DO NOTHING','claimed_count=claimed_count+1','already_claimed_on_website','maskEmail(user.email)','partner_approved','terms_url'):
        assert t in claim,t
    for t in ('currentUser()','dbTx(','FOR UPDATE OF v',"state='redeemed'",'WHERE id=$1 AND state=\'issued\'','property_partners','partner_verified'):
        assert t in redeem,t
    assert 'WHERE v.owner_key=$1' in wallet
    assert 'decryptCode' in wallet
    assert 'aes-256-gcm' in util and 'createHmac' in util and "randomBytes(18)" in util
    assert "origin === originAllowed" in util
    assert 'userId' not in claim and 'userId' not in wallet

def offer_contract():
    s=read('server-overlay/app/api/mobile/nav/offers/route.ts')
    for tok in ('isKorea(lat,lng)','funding_approved=true','partner_verified=true',"status='active'",'haversine(', 'no-store', 'location_saved:false'):
        if tok=='no-store':assert tok in read('server-overlay/lib/nav-wallet.ts')
        else:assert tok in s,tok
    assert "c.property_id='' OR c.property_id=p.property_id" in s

def android_contract():
    java=read('android-app/app/src/main/java/site/lexid/yeohangnav/MainActivity.java')
    gradle=read('android-app/app/build.gradle')
    kotlin=read('android-app/app/src/kakaoLink/java/site/lexid/yeohangnav/KakaoLaunchActivity.kt')
    for t in ('KAKAO_LINK_ENABLED','KAKAO_NATIVE_APP_KEY','enableLiveCoupons','requestLocationUpdates','removeUpdates','onPause','isFromMockProvider','onOffers'):
        assert t in java,t
    assert 'kakaoLinkImplementation' in gradle and 'v2-navi' in gradle
    for t in ('KakaoSdk.init','NaviClient.instance.navigateIntent','CoordType.WGS84','isKakaoNaviInstalled'):
        assert t in kotlin,t
    for p in ('android-app/app/src/main/AndroidManifest.xml','android-app/app/src/kakaoLink/AndroidManifest.xml','android-app/app/src/sdkNav/AndroidManifest.xml'):
        ElementTree.parse(ROOT/p)
    assert 'ACCESS_BACKGROUND_LOCATION' not in read('android-app/app/src/main/AndroidManifest.xml')

def ui_contract():
    html=read('android-app/app/src/main/assets/index.html')
    js=read('android-app/app/src/main/assets/app.js')
    for x in ('liveCouponToggle','refreshOffers','offerSummary','openCoupons','poiFilters'):
        assert f'id="{x}"' in html,x
    for t in ('onLiveLocation','onTrackingStopped','onOffers','navOffers','enableLiveCoupons'):
        assert t in js,t
    wallet=read('server-overlay/public/nav-wallet.js')
    for t in ('/api/mobile/nav/offers','/api/mobile/nav/wallet','/api/mobile/nav/claim','/api/mobile/nav/redeem','navigator.geolocation.getCurrentPosition'):
        assert t in wallet,t

def merger_contract():
    spec=importlib.util.spec_from_file_location('install_overlay',ROOT/'tools/install_overlay.py')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    with TemporaryDirectory() as tmp:
        repo=Path(tmp)
        (repo/'lib').mkdir();(repo/'app/api/mobile/pois').mkdir(parents=True)
        (repo/'package.json').write_text('{}')
        (repo/'lib/db.ts').write_text('ORIGINAL CONNECTION')
        old=repo/'app/api/mobile/pois/route.ts'
        old.write_text('ORIGINAL ROUTE')
        before=mod.install(repo,False)
        assert not (repo/'app/api/mobile/nav').exists()
        assert before['applied'] is False
        result=mod.install(repo,True)
        assert result['applied'] is True and result['backup_dir']
        assert (repo/'app/api/mobile/nav/claim/route.ts').exists()
        assert (Path(result['backup_dir'])/'app/api/mobile/pois/route.ts').read_text()=='ORIGINAL ROUTE'
        again=mod.install(repo,True)
        assert all(x['action']=='unchanged' for x in again['files'])
        assert (repo/'lib/db.ts').read_text()=='ORIGINAL CONNECTION'

if __name__=='__main__':
    tests=[('DB constraints and approval default',sql_contract),('Neon auth, idempotency, one-time redeem',auth_contract),('verified local coupon filtering',offer_contract),('Kakao Android and foreground location',android_contract),('web-to-native interface and promo wallet',ui_contract),('safe overlay installer and idempotent repeat',merger_contract)]
    for n,fn in tests:check(n,fn)
    print(f'PASSED ALL {len(tests)} v4 source contract groups; NOT a device/database integration test.')

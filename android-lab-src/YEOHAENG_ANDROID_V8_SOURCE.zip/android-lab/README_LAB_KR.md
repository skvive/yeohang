# 여행갈지도 Android v8 — 실제 빌드/에뮬레이터 검증 환경

## 현재 ChatGPT 컨테이너 진단 (2026-11-01)
- Debian 13 x86_64, JDK 21 존재, Node 22 존재
- Android SDK/adb/emulator/sdkmanager/gradle 부재
- 외부 DNS가 차단되어 dl.google.com/services.gradle.org Maven 다운로드 실패
- /dev/kvm 부재: 가속 에뮬레이터 불가
- 따라서 **이 컨테이너에서 APK build/adb install/실기기 테스트를 수행했다고 주장하지 않습니다.**

## A. Windows PC에서 실제 빌드
1. ZIP 해제 후 PowerShell을 엽니다. `android-lab/scripts/INSTALL_ANDROID_STUDIO_WINDOWS.ps1 -InstallStudio`를 실행합니다(필요한 경우).
2. Android Studio를 한 번 실행하고 SDK Manager에서 Android SDK Command-Line Tools (latest), API 36 설치 및 라이선스 동의를 마칩니다.
3. `android-lab/scripts/INSTALL_ANDROID_STUDIO_WINDOWS.ps1 -Build -CreateAvd`를 실행하여 SDK 36 + Gradle 8.13 빌드, API 35 AVD 생성까지 진행합니다.
4. 앱 APK: `android-app/app/build/outputs/apk/mapsLink/debug/*.apk`
5. 에뮬레이터 실행, `adb install -r <APK>` 후 지도·GPS·카테고리 전환을 검수합니다.
6. 브라우저 쿠폰·숙소가 동작하더라도 실시간 내비게이션 SDK는 별도 승인·검증이 필요합니다.

## B. GitHub Actions 클라우드 실험실
1. 압축파일을 Windows PC에 해제한 뒤 `android-lab/scripts/PUSH_ANDROID_TO_GITHUB_WINDOWS.ps1`을 실행하여 전체 Android 소스를 **별도 `android-nav-v8` 브랜치**에 업로드합니다. Git Credential Manager 승인이 필요하며 운영 `main`은 변경하지 않습니다.
2. GitHub > Actions > `Yeohaeng v8 Android Emulator Lab` > Run workflow.
3. 빌드는 Gradle 8.13/Android SDK API 36로 진행합니다.
4. 테스트는 Android 35 x86_64 에뮬레이터에서 APK 설치 및 실행, GPS 모의 위치(가락시장역), 모텔/프라이빗 하우스 Activity 실행을 수행합니다.
5. `YeohaengGaljido-v8-debug-apk`에서 디버그 APK, `YeohaengGaljido-v8-emulator-evidence`에서 화면·로그·UI XML을 내려받습니다.
6. GitHub Actions 결과를 확인하기 전에는 APK 빌드 또는 에뮬레이터 설치 성공으로 표시하지 마세요.

## 검수 기준
- **built**: 실제 Gradle 산출물 존재 & 해시 확인
- **installed-on-emulator**: adb install OK + pm path + 앱 실행
- **emulator-captured**: png/로그/XML 아티팩트
- **real-device-tested**: 별도 USB/실기기 확인 필요
- **signed**: 업로드 키로 릴리스 서명한 경우에만 통과
- **uploaded-to-play**: Google Play 업로드 확인이 있을 때만 통과

## 디버그 전용 Export
`android-app/app/src/debug/AndroidManifest.xml`은 지도 Activity를 테스트 용도로만 exported=true로 바꿉니다. 릴리스에서는 기존 `exported=false`를 유지합니다. 외부에서 권한 없이 테스트 Activity가 열리는 디버그 빌드를 고객에게 배포하면 안 됩니다.

## 주의
- 가락시장역 좌표는 사용자의 실제 위치가 아니며 GPS를 거부하면 기본 센터가 됩니다.
- 오프라인이나 OSM 타일 서버 차단 시 배경 지도 로딩이 실패할 수 있습니다.
- 숙소 데이터는 운영 API에 연결됩니다. 테스트 시 네트워크 허용이 필요하며 데이터베이스 수정은 하지 않습니다.
- 카카오 인앱 턴바이턴 네비게이션은 현재 구현되지 않았습니다.
- 기기의 USB 설치 및 GPS 실주행 검수는 물리적으로 연결된 기기에서만 가능합니다.

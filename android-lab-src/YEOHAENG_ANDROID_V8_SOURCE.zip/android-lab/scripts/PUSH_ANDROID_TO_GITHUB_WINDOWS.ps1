# Commit ONLY Android lab source to a dedicated branch. Requires Git Credential Manager login.
param([string]$Repo='https://github.com/skvive/yeohang.git',[string]$Branch='android-nav-v8')
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Temp=Join-Path $env:TEMP ('yeohang_android_upload_'+[guid]::NewGuid().ToString('N'))
if (!(Get-Command git -ErrorAction SilentlyContinue)) {throw 'Git for Windows must be installed and signed in; install from https://git-scm.com/downloads/win'}
if (!(Test-Path (Join-Path $Root 'android-app/settings.gradle'))) {throw 'android-app source missing'}
git clone --depth 1 --branch main $Repo $Temp
if ($LASTEXITCODE -ne 0) {throw 'Git clone failed. Check repository access.'}
try {
  Push-Location $Temp
  try {
    git switch -c $Branch
    if ($LASTEXITCODE -ne 0) {throw 'Branch exists. Use a new branch name.'}
    Copy-Item -Path (Join-Path $Root 'android-app') -Destination (Join-Path $Temp 'android-app') -Recurse -Force
    Copy-Item -Path (Join-Path $Root 'tests') -Destination (Join-Path $Temp 'tests') -Recurse -Force
    Copy-Item -Path (Join-Path $Root 'android-lab') -Destination (Join-Path $Temp 'android-lab') -Recurse -Force
    New-Item -ItemType Directory -Force '.github/workflows'|Out-Null
    Copy-Item (Join-Path $Root '.github/workflows/android-v8-emulator-lab.yml') '.github/workflows/android-v8-emulator-lab.yml' -Force
    git add android-app tests android-lab .github/workflows/android-v8-emulator-lab.yml
    git commit -m 'ci(android): add v8 app, SDK36 build and emulator validation'
    if ($LASTEXITCODE -ne 0) {throw 'Git commit failed; check git user.name/email.'}
    git push -u origin $Branch
    if ($LASTEXITCODE -ne 0) {throw 'Git push failed; check authentication and branch permissions.'}
    Write-Host "Uploaded $Branch to $Repo. Open GitHub Actions > Yeohaeng v8 Android Emulator Lab."
  } finally {Pop-Location}
} finally {Write-Host "Git worktree retained for review: $Temp"}

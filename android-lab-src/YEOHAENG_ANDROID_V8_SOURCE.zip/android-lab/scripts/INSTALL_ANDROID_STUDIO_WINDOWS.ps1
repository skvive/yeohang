# Run this on YOUR Windows desktop (not the restricted ChatGPT container).
param([switch]$InstallStudio,[switch]$Build,[switch]$CreateAvd)
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Android=Join-Path $Root 'android-app'
$Sdk= if ($env:ANDROID_HOME) {$env:ANDROID_HOME} elseif ($env:ANDROID_SDK_ROOT) {$env:ANDROID_SDK_ROOT} else {Join-Path $env:LOCALAPPDATA 'Android\Sdk'}
Write-Host "[YEOHAENG] Project=$Android; SDK=$Sdk"
if ($InstallStudio) {
  if (!(Get-Command winget -ErrorAction SilentlyContinue)) {throw 'winget missing. Install App Installer or Android Studio manually from developer.android.com/studio'}
  winget install -e --id Google.AndroidStudio --accept-package-agreements --accept-source-agreements
  Write-Host 'Open Android Studio ONCE to finish SDK setup, then run this script again without -InstallStudio.'
}
$SdkManager=Join-Path $Sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
if (!(Test-Path $SdkManager)) {
  Write-Warning "SDK Command-line Tools not found at $SdkManager. Open Android Studio > Settings > SDK Manager > SDK Tools > Android SDK Command-line Tools (latest)."
  if ($Build -or $CreateAvd) {throw 'SDK Manager unavailable; finish Android Studio first.'}
} else {
  Write-Host 'Installing/verifying Android SDK API 36 and Build Tools 36.0.0.'
  & $SdkManager '--sdk_root='+$Sdk 'platforms;android-36' 'build-tools;36.0.0' 'platform-tools'
  if ($LASTEXITCODE -ne 0) {throw 'SDK component installation failed.'}
}
if ($Build) {
  $javaPath=if ($env:JAVA_HOME) {$env:JAVA_HOME} else {Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'}
  if (!(Test-Path "$javaPath\bin\java.exe")) {throw 'JDK 17+ missing. Install Android Studio or set JAVA_HOME.'}
  $env:JAVA_HOME=$javaPath
  $env:ANDROID_HOME=$Sdk
  $env:PATH="$javaPath\bin;$(Join-Path $Sdk 'platform-tools');$env:PATH"
  # This v8 source uses a system Gradle adapter, not an included gradle-wrapper.jar.
  $GradleExe=Get-Command gradle -ErrorAction SilentlyContinue
  if (!$GradleExe) {
    $GradleDir=Join-Path $env:LOCALAPPDATA 'YeohaengAndroidLab\gradle-8.13'
    if (!(Test-Path "$GradleDir\bin\gradle.bat")) {
      $Parent=Split-Path $GradleDir -Parent;New-Item -Force -ItemType Directory -Path $Parent | Out-Null
      $ZipFile=Join-Path $Parent 'gradle-8.13-bin.zip'
      Write-Host 'Downloading official Gradle 8.13 binary distribution...'
      Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.13-bin.zip' -OutFile $ZipFile
      Expand-Archive -Path $ZipFile -DestinationPath $Parent -Force
    }
    $GradleCmd=Join-Path $GradleDir 'bin\gradle.bat'
  } else {$GradleCmd=$GradleExe.Source}
  Push-Location $Android
  try {
    & $GradleCmd '--no-daemon' ':app:assembleMapsLinkDebug'
    if ($LASTEXITCODE -ne 0) {throw 'Gradle build failed.'}
    Get-ChildItem 'app\build\outputs\apk\mapsLink\debug\*.apk' | Select-Object FullName,Length
  } finally { Pop-Location }
}
if ($CreateAvd) {
  $AvdManager=Join-Path $Sdk 'cmdline-tools\latest\bin\avdmanager.bat'
  & $SdkManager '--sdk_root='+$Sdk 'emulator' 'system-images;android-35;google_apis;x86_64'
  if ($LASTEXITCODE -ne 0) {throw 'Emulator image install failed.'}
  'no' | & $AvdManager create avd -n 'Yeohaeng_API35' -k 'system-images;android-35;google_apis;x86_64' -f
  Write-Host 'Run: <SDK>\emulator\emulator.exe -avd Yeohaeng_API35'
}

#!/usr/bin/env bash
set -euo pipefail
PKG=site.lexid.yeohangnav
ARTIFACTS="${ANDROID_LAB_ARTIFACTS:-$PWD/android-lab-results}"
mkdir -p "$ARTIFACTS"
APK="${ANDROID_LAB_APK:-$(find android-app/app/build/outputs/apk/mapsLink/debug -name '*.apk' -print -quit)}"
if [[ ! -s "$APK" ]];then echo 'ERROR: debug APK missing';exit 2;fi
adb wait-for-device
adb shell getprop sys.boot_completed | tr -d ''
adb install -r "$APK"
adb shell pm path "$PKG" | tee "$ARTIFACTS/install_path.txt"
# Debug-only activity manifest exports the map for deterministic emulator testing.
adb shell am force-stop "$PKG" || true
adb shell am start -W -n "$PKG/.MainActivity" | tee "$ARTIFACTS/home_launch.txt"
sleep 4
adb exec-out screencap -p > "$ARTIFACTS/01-home.png"
adb shell am start -W -n "$PKG/.NearbyMapActivity" --es category motel | tee "$ARTIFACTS/motel_launch.txt"
sleep 10
adb exec-out screencap -p > "$ARTIFACTS/02-motel-garak.png"
adb shell uiautomator dump /sdcard/window.xml >/dev/null || true
adb shell cat /sdcard/window.xml > "$ARTIFACTS/02-ui-hierarchy.xml" || true
adb emu geo fix 127.118060 37.493060 > "$ARTIFACTS/03-geo-fix.txt" 2>&1 || true
adb shell am force-stop "$PKG"
adb shell am start -W -n "$PKG/.NearbyMapActivity" --es category private | tee "$ARTIFACTS/private_launch.txt"
sleep 8
adb exec-out screencap -p > "$ARTIFACTS/04-private-garak.png"
adb logcat -d -v brief | grep -E 'FATAL EXCEPTION|AndroidRuntime|yeohangnav|NearbyMapActivity|chromium' | tail -200 > "$ARTIFACTS/logcat-filtered.txt" || true
if grep -q 'FATAL EXCEPTION.*' "$ARTIFACTS/logcat-filtered.txt";then
  echo 'Warning: FATAL EXCEPTION detected in logcat; inspect filtered log before accepting release.' >&2
  exit 1
fi
if ! grep -q 'site.lexid.yeohangnav' "$ARTIFACTS/install_path.txt";then echo 'ERROR package not installed';exit 3;fi
if ! grep -q 'Status: ok' "$ARTIFACTS/motel_launch.txt";then echo 'ERROR motel activity did not launch';exit 4;fi
if ! grep -q 'Status: ok' "$ARTIFACTS/private_launch.txt";then echo 'ERROR private house activity did not launch';exit 5;fi
printf 'INSTALL OK; launch OK; screenshot files generated. Manual review of pins, tiles, GPS permission, filtering still required.\n'

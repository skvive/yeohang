@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>&1 || (echo ERROR: Java JDK 17 or later required. & exit /b 1)
where gradle >nul 2>&1 || (echo ERROR: Gradle 8.13 required. Open this folder in Android Studio to install it. & exit /b 2)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (echo ERROR: Android SDK missing. Configure Android Studio SDK. & exit /b 3)
gradle --no-daemon :app:assembleMapsLinkDebug || exit /b 4
if not exist "app\build\outputs\apk\mapsLink\debug\app-mapsLink-debug.apk" (echo ERROR: Gradle returned but APK not found. & exit /b 5)
echo Debug APK build OK.
echo app\build\outputs\apk\mapsLink\debug\app-mapsLink-debug.apk

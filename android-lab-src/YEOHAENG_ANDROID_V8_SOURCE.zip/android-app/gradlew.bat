@echo off
where gradle >nul 2>&1
if errorlevel 1 (echo Gradle 8.13 is not installed. Android Studio can install Gradle automatically via the Gradle settings. & exit /b 2)
gradle %*

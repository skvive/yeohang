﻿@echo off
setlocal
set "APK=%~dp0..\YEOHAENG_GALJIDO_TEST_INSTALL.apk"
if not exist "%APK%" (
  echo APK missing; run BUILD_TEST_APK_WINDOWS.bat first.
  exit /b 2
)
where adb >nul 2>&1
if errorlevel 1 (
  echo adb missing: install Android SDK Platform Tools in Android Studio.
  exit /b 3
)
echo Connect your own Android phone with USB debugging enabled.
adb devices
adb install -r "%APK%"
if errorlevel 1 (echo INSTALL FAILED & exit /b 4)
echo Installed. Run the '여행갈지도' icon on your phone.
endlocal

@echo off
setlocal
cd /d "%~dp0"
where gradle >nul 2>&1
if errorlevel 1 (echo [ERROR] Gradle 8.13 and Android SDK 36 are required. Open the project in Android Studio first. & exit /b 2)
echo Building Android 16 API36 mapsLink variant...
call gradle --no-daemon :app:assembleMapsLinkDebug :app:bundleMapsLinkRelease
if errorlevel 1 exit /b 1
echo APK: app\build\outputs\apk\mapsLink\debug
 echo AAB unsigned: app\build\outputs\bundle\mapsLinkRelease

@echo off
setlocal
cd /d "%~dp0"
if "%MAPS_NAV_API_KEY%"=="" (echo [ERROR] Set Android-restricted MAPS_NAV_API_KEY and enable Navigation SDK in Google Cloud. & exit /b 2)
where gradle >nul 2>&1
if errorlevel 1 (echo [ERROR] Gradle 8.13 required. & exit /b 2)
call gradle --no-daemon :app:assembleSdkNavDebug

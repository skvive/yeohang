package site.lexid.yeohangnav

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.kakao.sdk.common.KakaoSdk
import com.kakao.sdk.navi.NaviClient
import com.kakao.sdk.navi.model.CoordType
import com.kakao.sdk.navi.model.Location
import com.kakao.sdk.navi.model.NaviOption

/** Official KakaoNavi App-to-App prototype. SDK with UI In-App uses a separate contract and integration. */
class KakaoLaunchActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val key = BuildConfig.KAKAO_NATIVE_APP_KEY
            if(key.isBlank()) throw IllegalStateException("카카오 네이티브 앱 키를 설정하세요.")
            KakaoSdk.init(this, key)
            val lat = intent.getDoubleExtra("lat", Double.NaN)
            val lng = intent.getDoubleExtra("lng", Double.NaN)
            if(!lat.isFinite() || !lng.isFinite() || lat !in 33.0..39.7 || lng !in 124.0..132.0)
                throw IllegalArgumentException("목적지 좌표 오류")
            val destination = Location(intent.getStringExtra("label") ?: "목적지", lng.toString(), lat.toString())
            val wp = intent.getStringExtra("waypoint")?.split(",")
            val via = if(wp?.size == 2) {
                val a=wp[0].toDoubleOrNull(); val b=wp[1].toDoubleOrNull()
                if(a != null && b != null && a in 33.0..39.7 && b in 124.0..132.0)
                    listOf(Location("선택한 경유지",b.toString(),a.toString())) else emptyList()
            } else emptyList()
            if (NaviClient.instance.isKakaoNaviInstalled(this)) {
                val navIntent=NaviClient.instance.navigateIntent(destination,NaviOption(coordType=CoordType.WGS84),via)
                startActivity(navIntent)
            } else {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.locnall.KimGiSa")))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "카카오내비 연결 실패: " + (e.message ?: "설정 확인"), Toast.LENGTH_LONG).show()
        } finally { finish() }
    }
}

/* 여행갈지도 v8 embedded discovery map. Local first-party JS, viewport-only OSM tiles.
   NO driving turn-by-turn. Location is fetched only after explicit user action.
   Remote property strings are inserted using textContent, never HTML. */
(function(root){
  'use strict';
  const $=s=>document.querySelector(s);
  const TYPES={all:'✦',hotel:'🏨',motel:'🛏️',pension:'🏡',private:'🏠',resort:'🌴',guesthouse:'🎒',hanok:'🏯',camping:'⛺',other:'📍'};
  const CENTER={lat:37.493060,lng:127.118060};
  const R=6371;
  const state={center:{...CENTER},display:{...CENTER},approved:false,category:'all',zoom:12,pins:[],selection:null,requestSeq:0, mapWidth:0,mapHeight:0,tilesSeen:new Set()};
  const android=root.YeoAndroidMap||null;
  const viewport=$('#map-viewport');
  const tileLayer=$('#tile-layer');
  const pinLayer=$('#pin-layer');
  const radiusLayer=$('#radius-layer');
  let drag=null,resizeTimer=null,requestedTiles=0,failedTiles=0;
  function finite(v){const x=Number(v);return Number.isFinite(x)?x:null;}
  function valid(p){const a=finite(p?.lat),b=finite(p?.lng);return a!==null&&b!==null&&a>=33&&a<=39.7&&b>=124&&b<=132;}
  function dist(a,b){const r=Math.PI/180,x=Math.sin((b.lat-a.lat)*r/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin((b.lng-a.lng)*r/2)**2;return R*2*Math.asin(Math.min(1,Math.sqrt(x)));}
  function world(lat,lng,z){const x=(lng+180)/360*256*2**z;const limited=Math.max(-85.05,Math.min(85.05,lat))*Math.PI/180;const y=(1-Math.log(Math.tan(limited)+1/Math.cos(limited))/Math.PI)/2*256*2**z;return{x,y};}
  function latlng(x,y,z){const n=256*2**z;return{lng:x/n*360-180,lat:Math.atan(Math.sinh(Math.PI*(1-2*y/n)))*180/Math.PI};}
  function px(lat,lng){const a=world(lat,lng,state.zoom),c=world(state.display.lat,state.display.lng,state.zoom);return{x:Math.round(a.x-c.x+state.mapWidth/2),y:Math.round(a.y-c.y+state.mapHeight/2)};}
  function node(tag,cls,content){const n=document.createElement(tag);if(cls)n.className=cls;if(content!==undefined)n.textContent=String(content);return n;}
  function text(id,value){const el=$(id);if(el)el.textContent=value;}
  function setCenterLabel(){text('#center-label',state.approved?'현재 위치 · 반경 5km':'가락시장역 · 기본 위치 (실제 내 위치 아님)');}
  function invalidateSelection(){state.selection=null;$('#map-popup').hidden=true;}
  function categoryUI(){document.querySelectorAll('[data-category]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.category===state.category)));}
  function choose(cat){
    if(!Object.hasOwn(TYPES,cat))return;
    state.category=cat;state.pins=[];state.requestSeq++;invalidateSelection();categoryUI();
    text('#results-count','선택한 숙소 찾는 중…');text('#status','반경 5km의 새 핀을 불러옵니다.');
    renderMarkers();renderList();
    if(android?.requestCategory)android.requestCategory(cat);
  }
  function drawTiles(){
    if(!state.mapWidth||!state.mapHeight)return;
    // Only the tiles under the current interactive viewport, never bulk prefetch.
    tileLayer.replaceChildren();
    const c=world(state.display.lat,state.display.lng,state.zoom);
    const left=c.x-state.mapWidth/2,top=c.y-state.mapHeight/2;
    const startX=Math.floor(left/256),endX=Math.floor((left+state.mapWidth)/256);
    const startY=Math.floor(top/256),endY=Math.floor((top+state.mapHeight)/256);
    const extent=2**state.zoom;
    for(let ty=startY;ty<=endY;ty++)for(let tx=startX;tx<=endX;tx++){
      if(ty<0||ty>=extent)continue;
      const image=node('img');image.alt='';image.decoding='async';image.loading='eager';
      image.style.left=(tx*256-left)+'px';image.style.top=(ty*256-top)+'px';
      image.src='https://tile.openstreetmap.org/'+state.zoom+'/'+((tx%extent+extent)%extent)+'/'+ty+'.png';
      image.addEventListener('error',()=>{failedTiles++;if(failedTiles>=2)$('#tile-notice').hidden=false;},{once:true});
      requestedTiles++;tileLayer.append(image);
    }
  }
  function drawRadius(){
    radiusLayer.replaceChildren();const p=px(state.center.lat,state.center.lng),mpp=156543.03392*Math.cos(state.center.lat*Math.PI/180)/2**state.zoom;
    const circle=node('div','radius-circle');const radius=5000/mpp;
    Object.assign(circle.style,{left:p.x+'px',top:p.y+'px',width:radius*2+'px',height:radius*2+'px'});
    const center=node('div','center-pin'+(state.approved?' gps':''));center.title=state.approved?'GPS 현재 위치':'가락시장역 기본 위치';center.style.left=p.x+'px';center.style.top=p.y+'px';
    radiusLayer.append(circle,center);
  }
  function pinIcon(type){return TYPES[type]||TYPES.other;}
  function buildClusters(){
    const groups=[];
    for(const p of state.pins){
      const pos=px(p.lat,p.lng);if(pos.x < -24||pos.x > state.mapWidth+24||pos.y < -20||pos.y>state.mapHeight+40)continue;
      const nearby=groups.find(group=>Math.hypot(group.x-pos.x,group.y-pos.y)<41);
      if(nearby){nearby.items.push(p);nearby.x=Math.round((nearby.x*(nearby.items.length-1)+pos.x)/nearby.items.length);nearby.y=Math.round((nearby.y*(nearby.items.length-1)+pos.y)/nearby.items.length);}else groups.push({x:pos.x,y:pos.y,items:[p]});
    }
    return groups;
  }
  function renderMarkers(){
    pinLayer.replaceChildren();
    for(const cluster of buildClusters()){
      const p=cluster.items[0],multi=cluster.items.length>1;
      const btn=node('button','marker'+(multi?' cluster':'')+(state.selection===p.id?' selected':''),multi?cluster.items.length:pinIcon(p.stay_type));
      btn.type='button';btn.style.left=cluster.x+'px';btn.style.top=cluster.y+'px';
      btn.setAttribute('aria-label',multi?cluster.items.length+'개 숙소가 모여 있습니다. 확대하여 보기':String(p.name||'숙소')+' 위치');
      btn.addEventListener('click',e=>{
        e.stopPropagation();
        if(multi){state.zoom=Math.min(17,state.zoom+2);state.display={lat:cluster.items.reduce((s,v)=>s+Number(v.lat),0)/cluster.items.length,lng:cluster.items.reduce((s,v)=>s+Number(v.lng),0)/cluster.items.length};draw();}
        else select(p);
      });
      pinLayer.append(btn);
    }
  }
  function popupAction(name,click){const b=node('button',null,name);b.type='button';b.addEventListener('click',click);return b;}
  function select(p){
    state.selection=p.id;
    const popup=$('#map-popup');popup.replaceChildren();
    const title=node('strong',null,p.name||'숙소');
    const line=node('p',null,[p.category||'숙소',p.city||'',Number(p.distance_km).toFixed(1)+'km'].filter(Boolean).join(' · '));
    const close=popupAction('×',()=>{invalidateSelection();renderMarkers();});close.className='close';close.setAttribute('aria-label','숙소 정보 닫기');
    const actions=node('div','actions');
    actions.append(popupAction('숙소 상세',()=>android?.openDetails?.(String(p.id))),popupAction('길찾기',()=>android?.navigate?.(p.lat,p.lng)));
    popup.append(close,title,line,actions);popup.hidden=false;
    document.querySelectorAll('.stay').forEach(row=>row.classList.toggle('selected',row.dataset.id===String(p.id)));
    renderMarkers();
  }
  function renderList(){
    const list=$('#results');list.replaceChildren();
    if(!state.pins.length){list.append(node('div','empty','선택한 유형의 숙소가 없습니다. 다른 유형을 선택해 보세요.'));return;}
    for(const p of state.pins){
      const row=node('article','stay');row.dataset.id=String(p.id);
      const icon=node('img');icon.src='mascot-meomuri.webp';icon.alt='';icon.loading='lazy';
      const body=node('div'),name=node('strong',null,p.name||'숙소'),meta=node('p',null,[p.category||'숙소',p.city||'',Number(p.distance_km).toFixed(1)+'km'].filter(Boolean).join(' · '));
      const button=popupAction('지도에서 보기',()=>{state.display={lat:p.lat,lng:p.lng};state.zoom=Math.max(state.zoom,14);draw();select(p);});
      body.append(name,meta,button);row.append(icon,body);list.append(row);
    }
  }
  function draw(){state.mapWidth=viewport.clientWidth;state.mapHeight=viewport.clientHeight;drawTiles();drawRadius();renderMarkers();}
  function zoom(delta){state.zoom=Math.max(9,Math.min(17,state.zoom+delta));draw();}
  function resetDisplay(){state.display={...state.center};state.zoom=12;draw();}
  function receive(raw){
    let d;try{d=JSON.parse(raw);}catch{return;}
    if(d.error){text('#status',d.error);text('#results-count','검색 실패');return;}
    if(d.category!==state.category)return; // Never show markers for a previously selected category.
    const pins=Array.isArray(d.pins)?d.pins:[];
    state.pins=pins.filter(p=>valid(p)&&Number.isFinite(Number(p.distance_km))&&Number(p.distance_km)<=5&&(state.category==='all'||p.stay_type===state.category)).slice(0,80).map(p=>({id:String(p.id||''),name:String(p.name||'숙소').slice(0,120),city:String(p.city||'').slice(0,60),category:String(p.category||''),stay_type:String(p.stay_type||'other'),lat:Number(p.lat),lng:Number(p.lng),distance_km:Number(p.distance_km)}));
    invalidateSelection();
    state.display={...state.center};state.zoom=12;
    text('#results-count',state.pins.length+'개 숙소 핀');
    text('#status',(state.approved?'내 위치':'가락시장역')+' 기준 · 반경 5km · 최대 80곳 표시');
    draw();renderList();
  }
  function locationChanged(raw){let d;try{d=JSON.parse(raw);}catch{return;}if(!valid(d))return;state.approved=d.gpsApproved===true;state.center=state.approved?{lat:Number(d.lat),lng:Number(d.lng)}:{...CENTER};state.display={...state.center};state.pins=[];invalidateSelection();setCenterLabel();draw();text('#status','새 위치에서 숙소를 찾는 중입니다.');}
  function bootstrap(raw){let d;try{d=JSON.parse(raw);}catch{return;}
    state.category=Object.hasOwn(TYPES,d.category)?d.category:'all';state.approved=d.gpsApproved===true&&valid(d);
    state.center=state.approved?{lat:Number(d.lat),lng:Number(d.lng)}:{...CENTER};state.display={...state.center};setCenterLabel();categoryUI();draw();choose(state.category);
  }
  const activePointers=new Map();let pinch=null;
  viewport.addEventListener('pointerdown',e=>{
    if(e.target.closest('button'))return;
    activePointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    viewport.setPointerCapture?.(e.pointerId);
    viewport.classList.add('dragging');$('#map-popup').hidden=true;
    if(activePointers.size===1){drag={x:e.clientX,y:e.clientY,start:world(state.display.lat,state.display.lng,state.zoom)};pinch=null;}
    if(activePointers.size===2){const pts=[...activePointers.values()];pinch={distance:Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y),zoom:state.zoom};drag=null;}
  });
  viewport.addEventListener('pointermove',e=>{
    if(!activePointers.has(e.pointerId))return;
    activePointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(activePointers.size===2&&pinch){
      const pts=[...activePointers.values()],distance=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);
      if(pinch.distance>0){const target=Math.round(pinch.zoom+Math.log2(Math.max(0.1,distance/pinch.distance)));
        const z=Math.max(9,Math.min(17,target));if(z!==state.zoom){state.zoom=z;draw();}}
      return;
    }
    if(!drag)return;
    const dx=e.clientX-drag.x,dy=e.clientY-drag.y;
    state.display=latlng(drag.start.x-dx,drag.start.y-dy,state.zoom);draw();
  });
  for(const event of ['pointerup','pointercancel'])viewport.addEventListener(event,e=>{
    activePointers.delete(e.pointerId);drag=null;pinch=null;
    if(activePointers.size===1){const p=[...activePointers.values()][0];drag={x:p.x,y:p.y,start:world(state.display.lat,state.display.lng,state.zoom)};}
    if(!activePointers.size)viewport.classList.remove('dragging');
  });
  viewport.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?1:-1);},{passive:false});
  $('#zoom-in').addEventListener('click',()=>zoom(1));$('#zoom-out').addEventListener('click',()=>zoom(-1));$('#recenter').addEventListener('click',resetDisplay);
  $('#back').addEventListener('click',()=>android?.closeMap?.());
  $('#use-gps').addEventListener('click',()=>android?.requestGps?.());
  $('#use-default').addEventListener('click',()=>android?.resetDefault?.());
  document.querySelectorAll('[data-category]').forEach(b=>b.addEventListener('click',()=>choose(b.dataset.category)));
  root.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(draw,90);});
  root.YeoMap={bootstrap,receive,locationChanged};
  if(!android){bootstrap(JSON.stringify({category:'all',lat:CENTER.lat,lng:CENTER.lng,gpsApproved:false}));text('#status','시연 모드: Android 앱에서 서버 데이터가 연결됩니다.');}
  if(typeof module==='object'&&module.exports)module.exports={dist,world,latlng,valid};
})(typeof window!=='undefined'?window:globalThis);

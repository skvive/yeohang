/* 여행갈지도 Android UI: personal location is kept on-device; remote API receives coordinates only when user requests nearby search. */
(function (root) {
  'use strict';
  const PLACES = [
    {id:'poi-gyeongbok',name:'경복궁',city:'서울',area:'종로구',type:'heritage',lat:37.5796,lng:126.9770,note:'서울의 대표적인 조선 궁궐'},
    {id:'poi-namsan',name:'남산서울타워',city:'서울',area:'용산구',type:'activity',lat:37.5512,lng:126.9882,note:'서울의 전망을 감상하는 명소'},
    {id:'poi-hanok',name:'북촌한옥마을',city:'서울',area:'종로구',type:'heritage',lat:37.5826,lng:126.9830,note:'한옥과 골목길을 만나는 산책 명소'},
    {id:'poi-haeundae',name:'해운대해수욕장',city:'부산',area:'해운대구',type:'nature',lat:35.1587,lng:129.1604,note:'도심과 바다가 만나는 해변'},
    {id:'poi-gamcheon',name:'감천문화마을',city:'부산',area:'사하구',type:'heritage',lat:35.0975,lng:129.0106,note:'골목길과 색채가 어우러진 문화마을'},
    {id:'poi-seongsan',name:'성산일출봉',city:'제주',area:'서귀포시',type:'nature',lat:33.4587,lng:126.9426,note:'제주 동쪽의 대표적인 자연 명소'},
    {id:'poi-jeonju',name:'전주한옥마을',city:'전주',area:'완산구',type:'heritage',lat:35.8154,lng:127.1530,note:'전통 한옥과 문화체험이 있는 여행지'},
    {id:'poi-gyeongju',name:'첨성대',city:'경주',area:'인왕동',type:'heritage',lat:35.8347,lng:129.2189,note:'신라 시대의 역사 유적'},
    {id:'poi-gangneung',name:'경포해변',city:'강릉',area:'안현동',type:'nature',lat:37.8059,lng:128.9092,note:'강릉의 대표 해변 여행지'}
  ];
  const MOODS = {
    sea:{title:'바다를 따라 달리는 오후',query:'Korean summer beach drive playlist',desc:'탁 트인 해안도로에 어울리는 산뜻한 팝과 여름 플레이리스트를 추천해요.'},
    mountain:{title:'초록빛 숲길 산책',query:'forest acoustic peaceful travel playlist',desc:'자연의 속도에 맞춘 어쿠스틱·인디 음악을 찾아보세요.'},
    city:{title:'도시의 불빛과 함께',query:'night city drive Korean R&B playlist',desc:'밤거리와 어울리는 알앤비·시티팝 분위기입니다.'},
    family:{title:'온 가족이 함께 떠나요',query:'family road trip happy playlist',desc:'함께 따라 부르기 좋은 밝은 로드트립 선곡을 찾아보세요.'},
    calm:{title:'천천히 쉬어 가는 여행',query:'calm relaxing instrumental travel playlist',desc:'조용한 숙소와 휴식을 위한 잔잔한 음악을 제안합니다.'},
    energetic:{title:'창문을 열고 출발!',query:'upbeat road trip songs playlist',desc:'출발할 때 설렘을 더하는 경쾌한 비트를 찾아보세요.'}
  };
  function distance(a,b,c,d){const r=Math.PI/180;const x=Math.sin((c-a)*r/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin((d-b)*r/2)**2;return 6371*2*Math.asin(Math.sqrt(x));}
  function safeCoord(v,min,max){const n=Number(v);return Number.isFinite(n)&&n>=min&&n<=max?n:null;}
  function inferMood(query){const q=String(query||'').toLowerCase();if(/바다|해변|오션|제주|부산|해운대|강릉/.test(q))return 'sea';if(/산|숲|지리산|설악|트레킹/.test(q))return 'mountain';if(/야경|서울|도심|홍대|명동/.test(q))return 'city';if(/아이|가족|어린이/.test(q))return 'family';if(/휴식|조용|힐링|한옥/.test(q))return 'calm';return 'energetic';}
  function routeList(input){const v=JSON.parse(input);return Array.isArray(v.routes)?v.routes.filter(x=>x&&Number.isFinite(Number(x.duration_min))):[];}
  if(typeof module!=='undefined'&&module.exports) module.exports={PLACES,MOODS,distance,safeCoord,inferMood,routeList};
  if(!root.document) return;
  const $=(s)=>document.querySelector(s);
  const dom=(tag, cls, content)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(content!=null)e.textContent=String(content);return e;};
  const app=root.AndroidApp||null;
  const state={lat:null,lng:null,stayCategory:'all',gpsApproved:false,selected:null,mode:'driving',option:'fast',mood:'sea',poiFilter:'all',hotels:[],livePlaces:[],lastOfferFetch:0};
  function notice(msg){const t=$('#toast');t.textContent=msg;t.style.display='block';clearTimeout(t._hide);t._hide=setTimeout(()=>{t.style.display='none'},3600)}
  root.onNotice=notice;
  const send=(method,...args)=>{if(!app||typeof app[method]!=='function'){notice('Android 앱에서 실행하면 실제 연결됩니다.');return;}try{app[method](...args)}catch(e){notice('기능을 실행하지 못했습니다.')}};
  function showTab(tab){$('.app').classList.toggle('discover-mode',tab==='discover');document.querySelectorAll('.bottomnav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.tab-section').forEach(t=>t.classList.toggle('active',t.id==='tab-'+tab));window.scrollTo({top:0,behavior:'auto'});if(tab==='coupons')send('coupons');}
  document.querySelectorAll('.bottomnav button').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
  const toCoupon=()=>showTab('coupons');$('#headerCoupon').addEventListener('click',toCoupon);$('#homeCouponCTA').addEventListener('click',toCoupon);
  document.querySelectorAll('.editorial-strip button').forEach(b=>b.addEventListener('click',()=>{$('#query').value=b.dataset.search;doSearch();}));
  function doSearch(){const q=$('#query').value.trim();if(!q){notice('여행지나 숙소를 입력해 주세요.');return;}showTab('discover');$('#results').replaceChildren(dom('div','empty','숙소 정보를 불러오는 중…'));$('#statusText').textContent='“'+q+'” 숙소 검색 중';setMood(inferMood(q));send('search',q);}
  $('#doSearch').addEventListener('click',doSearch);$('#query').addEventListener('keydown',e=>{if(e.key==='Enter')doSearch()});$('#voice').addEventListener('click',()=>send('voiceSearch'));root.onVoice=(txt)=>{$('#query').value=txt;doSearch();};
  document.querySelectorAll('#intents button').forEach(b=>b.addEventListener('click',()=>{$('#query').value=b.dataset.query;doSearch()}));
  const GARAK_CENTER={lat:37.493060,lng:127.118060};
  const MAP_TYPES=new Set(['all','hotel','motel','pension','private','resort','guesthouse','hanok','camping','other']);
  function fetchNearby(){
    const lat=state.gpsApproved?state.lat:GARAK_CENTER.lat;
    const lng=state.gpsApproved?state.lng:GARAK_CENTER.lng;
    if(lat==null||lng==null)return;
    const label=state.gpsApproved?'현재 위치 · 반경 5km':'가락시장역 · 반경 5km (실제 내 위치 아님)';
    $('#nearbyCenterLabel').textContent=label;
    $('#statusText').textContent=label+' · 숙소를 검색하고 있습니다…';
    send('nearbyFiltered',Number(lat),Number(lng),state.stayCategory,Boolean(state.gpsApproved));
  }
  document.querySelectorAll('#stayFilters [data-stay-type]').forEach(btn=>btn.addEventListener('click',()=>{
    const category=btn.dataset.stayType;
    if(!MAP_TYPES.has(category)||state.stayCategory===category)return;
    state.stayCategory=category;
    document.querySelectorAll('#stayFilters [data-stay-type]').forEach(b=>{
      const active=b.dataset.stayType===category;b.classList.toggle('selected',active);b.setAttribute('aria-pressed',String(active));
    });
    $('#results').replaceChildren(dom('div','empty','선택한 숙소 유형을 불러오는 중입니다…'));
    fetchNearby();
  }));
  $('#openNearbyMap').addEventListener('click',()=>send('openNearbyMap',state.stayCategory,Number(state.gpsApproved?state.lat:GARAK_CENTER.lat),Number(state.gpsApproved?state.lng:GARAK_CENTER.lng),Boolean(state.gpsApproved)));
  $('#locate').addEventListener('click',()=>send('getLocation'));
  root.onLocationUnavailable=()=>{state.lat=null;state.lng=null;state.gpsApproved=false;fetchNearby();};
  root.onLocation=function(raw){try{const p=JSON.parse(raw);state.lat=safeCoord(p.lat,33,39.7);state.lng=safeCoord(p.lng,124,132);if(state.lat==null||state.lng==null)throw Error();state.gpsApproved=true;fetchNearby();send('pois',state.lat,state.lng);showTab('discover');}catch(e){notice('위치를 읽을 수 없습니다.')}};
  function setDest(options){const sel=$('#routeDest'), prev=state.selected&&state.selected.id;sel.replaceChildren();options.forEach(o=>{const opt=dom('option',null,o.name+' · '+(o.city||''));opt.value=o.id;sel.append(opt)});state.destList=options;if(prev&&options.some(x=>x.id===prev))sel.value=prev;else if(options.length) sel.value=options[0].id;state.selected=options.find(x=>x.id===sel.value)||null;const waypoint=$('#routeWaypoint');const old=waypoint.value;waypoint.replaceChildren();const none=dom('option',null,'경유 없이 바로 가기');none.value='';waypoint.append(none);(state.livePlaces.length?state.livePlaces:PLACES).forEach(o=>{if(state.selected&&o.id===state.selected.id)return;const opt=dom('option',null,o.name);opt.value=o.id;waypoint.append(opt)});if(old&&(state.livePlaces.length?state.livePlaces:PLACES).some(x=>x.id===old))waypoint.value=old;}
  function selectDest(p){state.selected=p;const opts=[p,...(state.destList||PLACES).filter(x=>x.id!==p.id)];setDest(opts);showTab('nav')}
  function renderHotels(hotels, source){const container=$('#results');container.replaceChildren();state.hotels=hotels.slice(0,50);if(!hotels.length){container.append(dom('div','empty','검색 결과가 없습니다. 다른 지역이나 검색어로 다시 찾아주세요.'));return;}
    hotels.slice(0,24).forEach(p=>{
      const card=dom('article','stay-card');const photo=dom('div','photo');const url=String(p.photo_url||'');if(url.startsWith('https://')&&(p.photo_license||p.source==='agoda')){const im=dom('img');im.src=url;im.alt=p.name||'숙소 사진';im.onerror=()=>{photo.replaceChildren(dom('span',null,'등록된 사진을 확인하는 중'))};photo.append(im)}else {const visual=dom('img');visual.src='editorial-'+(/제주|서귀포/.test(String(p.city))?'jeju':/전주|경주/.test(String(p.city))?'hanok':/부산/.test(String(p.city))?'busan':'seoul')+'.webp';visual.alt='AI 생성 지역 여행 콘셉트 이미지. 실제 숙소 사진 아님';photo.append(visual,dom('span','photo-label','여행 테마 이미지 · 실제 숙소 사진 아님'));}
      const body=dom('div','body'),tag=dom('div','tag',(p.sponsored?'스폰서 광고 · ':'')+(p.city||'국내')+' · '+(p.category||'숙소'));
      const name=dom('h3',null,p.name||'이름 확인 필요');const address=dom('p',null,p.address||'숙소 위치 정보 확인 필요');const actions=dom('div','actions');const pin=dom('button','action-primary','길안내 ↗');pin.addEventListener('click',()=>{const lat=safeCoord(p.lat,33,39.7),lng=safeCoord(p.lng,124,132);if(lat==null||lng==null){notice('이 숙소는 정확한 좌표 확인이 필요합니다.');return;}selectDest({id:p.id,name:p.name,city:p.city,lat,lng});});const book=dom('button',null,'숙소 정보 / 예약');book.addEventListener('click',()=>send('openLink','https://yeohang.lexid.site/stay/'+encodeURIComponent(String(p.id))));actions.append(pin,book);body.append(tag,name,address,actions);card.append(photo,body);container.append(card);
    });$('#statusText').textContent='숙소 '+hotels.length+'건 · '+source+' · 요금/예약은 제휴사 확인';
    setDest([...state.hotels.filter(p=>safeCoord(p.lat,33,39.7)!=null&&safeCoord(p.lng,124,132)!=null).slice(0,24).map(p=>({...p,lat:Number(p.lat),lng:Number(p.lng)})),...(state.livePlaces.length?state.livePlaces:PLACES)]);
  }
  root.onProperties=function(raw){try{const v=JSON.parse(raw);if(v.error){notice(v.error);return;}const r=Array.isArray(v.results)?v.results:[];renderHotels(r,'연결된 숙소 DB');}catch(e){notice('숙소 응답 형식이 올바르지 않습니다.')}};
  root.onNearby=function(raw){try{const v=JSON.parse(raw);if(v.error){notice(v.error);return;}const pts=(Array.isArray(v.pins)?v.pins:[]).filter(p=>Number.isFinite(Number(p.distance_km))&&Number(p.distance_km)<=5&&(state.stayCategory==='all'||p.stay_type===state.stayCategory));renderHotels(pts,'반경 5km · '+(state.gpsApproved?'내 위치':'가락시장역 기준'));}catch(e){notice('주변 숙소 데이터를 표시할 수 없습니다.')}};
  root.onPois=function(raw){try{const v=JSON.parse(raw);if(v.error){notice('공공 관광정보가 잠시 중단되어 예시 관광지를 표시합니다.');return;}const arr=Array.isArray(v.places)?v.places:[];state.livePlaces=arr.filter(p=>typeof p.name==='string' && safeCoord(p.lat,33,39.7)!=null && safeCoord(p.lng,124,132)!=null).map(p=>({...p,lat:Number(p.lat),lng:Number(p.lng)}));renderPois();if(state.livePlaces.length) setDest([...state.hotels.filter(p=>safeCoord(p.lat,33,39.7)!=null),...state.livePlaces]);}catch(e){notice('관광정보 형식이 올바르지 않습니다.')}};
  function renderPois(){const list=$('#poiList');list.replaceChildren();let items=(state.livePlaces.length?state.livePlaces:PLACES).filter(p=>state.poiFilter==='all'||p.type===state.poiFilter);if(state.lat!=null&&state.lng!=null)items=items.map(p=>({...p,d:distance(state.lat,state.lng,p.lat,p.lng)})).sort((a,b)=>a.d-b.d);items.forEach(p=>{const card=dom('article','poi-card'),top=dom('div','poi-top');const picture=dom('div','poi-cover');const pic=dom('img');pic.src='editorial-'+(/제주|서귀포/.test(p.city)?'jeju':/부산/.test(p.city)?'busan':/전주|경주/.test(p.city)?'hanok':/강릉/.test(p.city)?'forest':'seoul')+'.webp';pic.alt='AI 생성 여행 테마 이미지. 실제 관광지 사진이 아닙니다.';picture.append(pic,dom('span','photo-label','여행 테마 · AI 이미지'));card.append(picture);top.append(dom('h3',null,p.name),dom('span','pill',p.city));card.append(top,dom('p',null,p.note+(p.d!=null?' · 약 '+p.d.toFixed(1)+'km (직선거리)':'')));const actions=dom('div','actions');const nav=dom('button','action-primary','길안내');nav.addEventListener('click',()=>selectDest(p));const map=dom('button',null,'지도 보기');map.addEventListener('click',()=>send('navigate',p.name,p.lat,p.lng,'walking','fast',''));const voice=dom('button',null,'음성 소개');voice.addEventListener('click',()=>send('speak',p.name+'. '+p.note));actions.append(nav,map,voice);card.append(actions);list.append(card)})}
  document.querySelectorAll('#poiFilters button').forEach(b=>b.addEventListener('click',()=>{state.poiFilter=b.dataset.filter;document.querySelectorAll('#poiFilters button').forEach(x=>x.classList.toggle('selected',x===b));renderPois()}));$('#refreshNearby').addEventListener('click',()=>{if(state.lat!=null&&state.lng!=null)send('pois',state.lat,state.lng);else notice('현재 위치를 먼저 허용하면 공공 관광정보를 조회합니다.');renderPois()});
  $('#routeDest').addEventListener('change',e=>{state.selected=state.destList.find(p=>p.id===e.target.value)});
  for(const group of ['#routeMode','#routeOption']) document.querySelectorAll(group+' button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll(group+' button').forEach(x=>x.classList.toggle('selected',x===b));if(group==='#routeMode'){state.mode=b.dataset.mode;$('#routeOption').style.display=state.mode==='driving'?'flex':'none'}else state.option=b.dataset.opt}));
  $('#startNav').addEventListener('click',()=>{const p=state.selected;if(!p){notice('목적지를 선택해 주세요.');return;}const waypoint=(state.livePlaces.length?state.livePlaces:PLACES).find(x=>x.id===$('#routeWaypoint').value);send('navigate',p.name,Number(p.lat),Number(p.lng),state.mode,state.option==='fast'?'':state.option,waypoint?waypoint.lat+','+waypoint.lng:'')});
  $('#showTraffic').addEventListener('click',()=>{const p=state.selected||{lat:37.5665,lng:126.978};send('traffic',state.lat||p.lat,state.lng||p.lng)});
  $('#compareRoutes').addEventListener('click',()=>{const p=state.selected;if(state.lat==null||state.lng==null){notice('먼저 GPS로 현재 위치를 확인하세요.');return;}if(!p){notice('목적지를 선택해 주세요.');return;}$('#trafficStatus').textContent='공식 교통 API에서 조회 중…';$('#routesList').replaceChildren();send('routeOptions',state.lat,state.lng,Number(p.lat),Number(p.lng))});
  root.onRoutes=function(raw){try{const v=JSON.parse(raw);if(v.error){$('#trafficStatus').textContent=v.error;return;}const routes=routeList(raw);if(!routes.length){$('#trafficStatus').textContent='교통 API 응답에서 유효한 경로가 없습니다.';return;}$('#trafficStatus').textContent='실시간 교통정보 조회 결과 · 운행 상황에 따라 달라질 수 있습니다.';const list=$('#routesList');routes.forEach(r=>list.append(dom('div','route-result',(r.label||'경로')+' · 약 '+r.duration_min+'분 · '+r.distance_km+'km'+(r.toll_krw!=null?' · 통행료 '+r.toll_krw+'원':''))))}catch(e){$('#trafficStatus').textContent='경로 응답 분석 오류'}};
  root.onCoupons=function(raw){const list=$('#couponList');list.replaceChildren();try{const v=JSON.parse(raw),coupons=Array.isArray(v.campaigns)?v.campaigns:[];if(!coupons.length){list.append(dom('div','empty','진행 중인 승인된 쿠폰이 없습니다.'));return;}coupons.slice(0,12).forEach(c=>{const card=dom('article','coupon-card');card.append(dom('span','coupon-status',c.verified_benefit?'✓ 제휴 승인 행사 · 조건 확인':'체험 행사 · 실사용 불가'));card.append(dom('h3',null,c.title));card.append(dom('p',null,c.subtitle||'행사 약관을 확인하세요.'));list.append(card)})}catch(e){list.append(dom('div','empty','쿠폰 정보를 불러오지 못했습니다.'))}};
  // Foreground-only device positioning and explicitly requested nearby-offer search.
  const refreshOffers=()=>{
    if(state.lat==null||state.lng==null){notice('먼저 내 위치를 허용하세요.');send('getLocation');return}
    state.lastOfferFetch=Date.now();send('navOffers',state.lat,state.lng);
  };
  $('#refreshOffers').addEventListener('click',refreshOffers);
  $('#liveCouponToggle').addEventListener('change',e=>{
    send('enableLiveCoupons',Boolean(e.target.checked));
    if(e.target.checked)refreshOffers();
  });
  root.onTrackingStopped=()=>{const el=$('#liveCouponToggle');if(el)el.checked=false;};
  root.onLiveLocation=function(raw){try{
    const p=JSON.parse(raw);const lat=safeCoord(p.lat,33,39.7),lng=safeCoord(p.lng,124,132);
    if(lat==null||lng==null)return;
    state.lat=lat;state.lng=lng;
    if($('#liveCouponToggle').checked && Date.now()-state.lastOfferFetch>45000)refreshOffers();
  }catch(e){notice('실시간 위치를 해석하지 못했습니다.')}};
  root.onOffers=function(raw){
    const list=$('#offerSummary');list.replaceChildren();
    try{
      const v=JSON.parse(raw);if(v.error)throw Error(v.error);
      const offers=Array.isArray(v.offers)?v.offers:[];
      if(!offers.length){list.append(dom('div','empty','근처에 승인된 제휴 쿠폰이 없습니다.'));return}
      offers.slice(0,12).forEach(o=>{
        const c=dom('article','coupon-card');c.append(dom('span','coupon-status','✓ 제휴 승인 · 직선거리 '+(Number(o.distance_m)/1000).toFixed(1)+'km'),dom('h3',null,o.title),dom('p',null,o.label+' · '+o.valid_until+'까지'));
        const btn=dom('button','secondary','쿠폰 지갑에서 발급 ↗');btn.addEventListener('click',()=>send('openLink','https://yeohang.lexid.site/nav-wallet.html'));
        c.append(btn);list.append(c);
      });
    }catch(e){list.append(dom('div','empty','실제 제휴 혜택을 불러올 수 없습니다.'));}
  };
  $('#reloadCoupons').addEventListener('click',()=>send('coupons'));$('#openCoupons').addEventListener('click',()=>send('openLink','https://yeohang.lexid.site/nav-wallet.html'));
  function setMood(mood){state.mood=mood;document.querySelectorAll('#moods button').forEach(b=>b.classList.toggle('selected',b.dataset.mood===mood));const m=MOODS[mood];$('#musicSuggestion').replaceChildren(dom('strong',null,m.title),dom('p',null,m.desc),dom('div','section-label','음악 검색어 · '+m.query));}
  document.querySelectorAll('#moods button').forEach(b=>b.addEventListener('click',()=>setMood(b.dataset.mood)));
  $('#openMusic').addEventListener('click',()=>send('music',MOODS[state.mood].query));
  setDest(PLACES);renderPois();setMood('sea');if(app&&typeof app.nearbyFiltered==='function')fetchNearby();
})(typeof window!=='undefined'?window:globalThis);

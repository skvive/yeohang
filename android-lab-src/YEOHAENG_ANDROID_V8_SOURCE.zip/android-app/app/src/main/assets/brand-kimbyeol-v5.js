/* Kim Byeol brand enhancement. Calls existing tab handlers; does not alter navigation/GPS permissions. */
(()=>{'use strict';
 document.querySelectorAll('[data-kim-nav]').forEach(btn=>btn.addEventListener('click',()=>{
  const name=btn.getAttribute('data-kim-nav');
  const tab=document.querySelector('.bottomnav [data-tab="'+name+'"]');
  if(tab){tab.click(); window.scrollTo({top:0,behavior:'smooth'});}
 }));
})();

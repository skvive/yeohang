package site.lexid.yeohangnav;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import android.net.Uri;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Build;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String API = "https://yeohang.lexid.site";
    private static final int LOCATION_REQUEST = 114;
    private static final int VOICE_REQUEST = 115;
    private WebView view;
    private TextToSpeech tts;
    private CacheStore offline;
    // On-device foreground-only location updates. NEVER persist/transmit location automatically.
    private boolean liveCouponsEnabled = false;
    private boolean livePermissionPending = false;
    private LocationManager liveManager;
    private LocationListener liveListener;
    private long lastLiveSentAt = 0L;
    private Location lastLiveLocation;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF092D43);
        getWindow().setNavigationBarColor(0xFF092D43);
        offline = new CacheStore(this);
        view = new WebView(this);
        if (Build.VERSION.SDK_INT >= 35) {
            getWindow().setDecorFitsSystemWindows(false);
            view.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return !"file:///android_asset/index.html".equals(uri.toString());
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
                if ("https".equals(uri.getScheme()) && (host.equals("google.com") || host.endsWith(".google.com") || host.equals("music.youtube.com") || host.equals("youtube.com") || host.endsWith(".youtube.com") || host.equals("yeohang.lexid.site"))) {
                    launch(uri); return true;
                }
                return true;
            }
        });
        view.addJavascriptInterface(new Bridge(), "AndroidApp");
        setContentView(view);
        view.loadUrl("file:///android_asset/index.html");
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.KOREAN);
        });
    }

    private void js(String callback, String json) {
        runOnUiThread(() -> view.evaluateJavascript("if(typeof window."+callback+"==='function'){window." + callback + "(" + JSONObject.quote(json) + ")}", null));
    }
    private void launch(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (ActivityNotFoundException ex) { runOnUiThread(() -> Toast.makeText(this, "연결할 앱이 없습니다.", Toast.LENGTH_SHORT).show()); }
    }
    private static boolean valid(double lat, double lon) {
        return Double.isFinite(lat) && Double.isFinite(lon) && lat>=33 && lat<=39.7 && lon>=124 && lon<=132;
    }
    private void loadApi(String path, String callback) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(API + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(9000); conn.setReadTimeout(12000);
                conn.setRequestProperty("Accept", "application/json");
                int status = conn.getResponseCode();
                if (status < 200 || status >= 300) throw new IllegalStateException("HTTP " + status);
                StringBuilder b = new StringBuilder();
                try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String line; while ((line = in.readLine()) != null && b.length() < 650000) b.append(line);
                }
                String payload = b.toString();
                if (payload.length() > 400000) throw new IllegalStateException("response too large");
                if (!path.contains("lat=") && !path.contains("lng=") && (path.startsWith("/api/properties") || path.equals("/api/promos"))) offline.put(path, payload);
                js(callback, payload);
            } catch (Exception ex) {
                String previous = offline.get(path);
                if (previous != null) js(callback, previous);
                else js(callback, "{\"error\":\"서버 연결 실패. 최근 정보가 없습니다.\"}");
            }
            finally { if(conn!=null) conn.disconnect(); }
        }).start();
    }

    public class Bridge {
        @JavascriptInterface public void search(String query) {
            String q = query == null ? "" : query.trim();
            if (q.length() > 150) q = q.substring(0,150);
            loadApi("/api/properties?q=" + Uri.encode(q), "onProperties");
        }
        @JavascriptInterface public void nearby(double lat, double lon) {
            nearbyFiltered(lat,lon,"all",true);
        }
        @JavascriptInterface public void nearbyFiltered(double lat, double lon, String category, boolean gpsApproved) {
            if (!valid(lat, lon)) { js("onNearby", "{\"error\":\"대한민국 내 좌표만 지원합니다.\"}"); return; }
            String safeCategory = category == null ? "all" : category.toLowerCase(Locale.ROOT);
            if (!safeCategory.matches("all|hotel|motel|pension|private|resort|guesthouse|hanok|camping|other")) safeCategory = "all";
            String origin = gpsApproved ? "gps" : "default";
            loadApi("/api/map?lat=" + lat + "&lng=" + lon + "&category=" + Uri.encode(safeCategory)
                + "&origin=" + origin, "onNearby");
        }
        @JavascriptInterface public void openNearbyMap(String category, double lat, double lon, boolean gpsApproved) {
            String safeCategory = category == null ? "all" : category.toLowerCase(Locale.ROOT);
            if (!safeCategory.matches("all|hotel|motel|pension|private|resort|guesthouse|hanok|camping|other")) safeCategory = "all";
            boolean permitted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            boolean withGps = gpsApproved && permitted && valid(lat,lon);
            Intent intent = new Intent(MainActivity.this, NearbyMapActivity.class);
            intent.putExtra("category",safeCategory);
            intent.putExtra("gpsApproved",withGps);
            if(withGps) { intent.putExtra("lat",lat); intent.putExtra("lng",lon); }
            runOnUiThread(() -> startActivity(intent));
        }
        @JavascriptInterface public void coupons() { loadApi("/api/promos", "onCoupons"); }
        @JavascriptInterface public void navOffers(double lat, double lon) {
            if (!valid(lat,lon)) { js("onOffers", "{\"offers\":[]}"); return; }
            loadApi("/api/mobile/nav/offers?lat=" + lat + "&lng=" + lon, "onOffers");
        }
        @JavascriptInterface public void enableLiveCoupons(boolean enabled) {
            runOnUiThread(() -> {
                if (!enabled) { stopLiveLocation(); return; }
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    livePermissionPending = true;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                } else startLiveLocation();
            });
        }
        @JavascriptInterface public void pois(double lat, double lon) {
            if (!valid(lat, lon)) { js("onNotice", "국내 위치에서 관광지 정보를 확인할 수 있습니다."); return; }
            loadApi("/api/mobile/pois?lat=" + lat + "&lng=" + lon, "onPois");
        }
        @JavascriptInterface public void routeOptions(double startLat, double startLon, double destLat, double destLon) {
            if (!valid(startLat,startLon) || !valid(destLat,destLon)) { js("onRoutes", "{\"error\":\"유효하지 않은 좌표\"}"); return; }
            loadApi("/api/mobile/routes?startLat="+startLat+"&startLng="+startLon+"&endLat="+destLat+"&endLng="+destLon, "onRoutes");
        }
        @JavascriptInterface public void getLocation() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                    return;
                }
                reportLocation();
            });
        }
        @JavascriptInterface public void navigate(String label, double lat, double lon, String mode, String option, String waypoint) {
            if (!valid(lat,lon)) { js("onNotice", "목적지 좌표가 유효하지 않습니다."); return; }
            String travel = ("walking".equals(mode) || "transit".equals(mode)) ? mode : "driving";
            Uri.Builder fallback = Uri.parse("https://www.google.com/maps/dir/").buildUpon()
                .appendQueryParameter("api", "1").appendQueryParameter("destination", lat + "," + lon)
                .appendQueryParameter("travelmode", travel).appendQueryParameter("dir_action", "navigate");
            if ("tolls".equals(option) || "highways".equals(option)) fallback.appendQueryParameter("avoid", option);
            if (waypoint != null && waypoint.matches("\\d{1,2}\\.\\d{1,8},1\\d{2}\\.\\d{1,8}")) {
                String[] parts = waypoint.split(",");
                if (valid(Double.parseDouble(parts[0]), Double.parseDouble(parts[1]))) fallback.appendQueryParameter("waypoints", waypoint);
            }
            if ("driving".equals(travel) && BuildConfig.KAKAO_LINK_ENABLED && !BuildConfig.KAKAO_NATIVE_APP_KEY.isEmpty()) {
                runOnUiThread(() -> {
                    try {
                        Class<?> clazz = Class.forName("site.lexid.yeohangnav.KakaoLaunchActivity");
                        Intent intent = new Intent(MainActivity.this, clazz);
                        intent.putExtra("lat",lat); intent.putExtra("lng",lon);
                        intent.putExtra("label",label); intent.putExtra("waypoint", waypoint);
                        // Kakao Navi handles turn-by-turn, not this app. Never claim in-app guidance here.
                        startActivity(intent);
                    } catch (Exception ex) { launch(fallback.build()); }
                });
            } else if ("driving".equals(travel) && BuildConfig.NAVIGATION_SDK_ENABLED) {
                runOnUiThread(() -> {
                    try {
                        Class<?> clazz=Class.forName("site.lexid.yeohangnav.NavigationActivity");
                        Intent intent=new Intent(MainActivity.this,clazz);
                        intent.putExtra("lat",lat);intent.putExtra("lng",lon);intent.putExtra("label",label);
                        startActivity(intent);
                    } catch (Exception ex) { launch(fallback.build()); }
                });
            } else runOnUiThread(() -> launch(fallback.build()));
        }
        @JavascriptInterface public void traffic(double lat, double lon) {
            if (!valid(lat,lon)) return;
            Uri u = Uri.parse("https://www.google.com/maps/@").buildUpon().appendQueryParameter("api","1")
                .appendQueryParameter("map_action","map").appendQueryParameter("center",lat+","+lon)
                .appendQueryParameter("zoom","12").appendQueryParameter("layer","traffic").build();
            runOnUiThread(() -> launch(u));
        }
        @JavascriptInterface public void music(String phrase) {
            String query = phrase == null ? "여행 드라이브 음악" : phrase.trim();
            if (query.length() > 100) query=query.substring(0,100);
            Uri u = Uri.parse("https://music.youtube.com/search").buildUpon().appendQueryParameter("q",query).build();
            runOnUiThread(() -> launch(u));
        }
        @JavascriptInterface public void speak(String text) {
            String safe = text == null ? "" : text.replaceAll("[\\r\\n]", " ");
            if (safe.length() > 140) safe = safe.substring(0,140);
            final String s = safe;
            runOnUiThread(() -> { if (tts != null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"travel-voice"); });
        }
        @JavascriptInterface public void voiceSearch() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ko-KR");
                    i.putExtra(RecognizerIntent.EXTRA_PROMPT,"어디로 여행할까요?");
                    startActivityForResult(i, VOICE_REQUEST);
                } catch (Exception e) { Toast.makeText(MainActivity.this,"음성 입력 앱이 없습니다.",Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void openLink(String url) {
            try {
                Uri uri = Uri.parse(url);
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
                if (!"https".equals(uri.getScheme())) return;
                boolean good = host.equals("yeohang.lexid.site") || host.equals("www.agoda.com") || host.equals("agoda.com") || host.equals("music.youtube.com") || host.equals("www.youtube.com");
                if (good) runOnUiThread(() -> launch(uri));
            } catch (Exception ignored) { }
        }
    }
    private void reportLocation() {
        try {
            LocationManager mgr = (LocationManager)getSystemService(LOCATION_SERVICE);
            Location loc = mgr.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc == null) loc = mgr.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (loc != null && System.currentTimeMillis() - loc.getTime() <= 10 * 60 * 1000
                && valid(loc.getLatitude(),loc.getLongitude())) {
                js("onLocation", "{\"lat\":"+loc.getLatitude()+",\"lng\":"+loc.getLongitude()+"}");
                return;
            }
            if (Build.VERSION.SDK_INT >= 30) {
                String provider = mgr.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
                    ? LocationManager.NETWORK_PROVIDER : LocationManager.GPS_PROVIDER;
                mgr.getCurrentLocation(provider, null, getMainExecutor(), fresh -> {
                    if (fresh != null && valid(fresh.getLatitude(), fresh.getLongitude()))
                        js("onLocation", "{\"lat\":"+fresh.getLatitude()+",\"lng\":"+fresh.getLongitude()+"}");
                    else { js("onNotice", "위치를 아직 확인하지 못했습니다. 가락시장역으로 검색합니다."); js("onLocationUnavailable", "{}"); }
                });
            } else { js("onNotice", "위치를 아직 확인하지 못했습니다. 가락시장역으로 검색합니다."); js("onLocationUnavailable", "{}"); }
        } catch (SecurityException ignored) { js("onLocationUnavailable", "{}"); js("onNotice", "위치 권한이 없어 가락시장역 기준으로 검색합니다."); }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if (requestCode == LOCATION_REQUEST && results.length > 0 && ((results[0] == PackageManager.PERMISSION_GRANTED) || (results.length > 1 && results[1] == PackageManager.PERMISSION_GRANTED))) {
            if(livePermissionPending) { livePermissionPending=false; startLiveLocation(); }
            else reportLocation();
        }
        else if(requestCode == LOCATION_REQUEST) { livePermissionPending=false; js("onLocationUnavailable", "{}"); js("onNotice", "위치 권한 없이 가락시장역 5km 내 숙소를 표시합니다."); }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == VOICE_REQUEST && resultCode==RESULT_OK && data!=null) {
            ArrayList<String> results=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results!=null && !results.isEmpty()) js("onVoice", results.get(0));
        }
    }
    @Override public void onBackPressed() {
        if (view.canGoBack()) view.goBack(); else super.onBackPressed();
    }
    private void startLiveLocation() {
        stopLiveLocation();
        try {
            liveManager=(LocationManager)getSystemService(LOCATION_SERVICE);
            liveListener = loc -> {
                if(!liveCouponsEnabled || loc==null || !valid(loc.getLatitude(),loc.getLongitude())) return;
                if(loc.getAccuracy() > 150 || loc.isFromMockProvider()) return;
                long now=System.currentTimeMillis();
                // 10 seconds minimum between UI updates, or 30 meters movement; no raw path history.
                if(now-lastLiveSentAt<10000) return;
                if(lastLiveLocation!=null && lastLiveLocation.distanceTo(loc)<30 && now-lastLiveSentAt<30000) return;
                lastLiveSentAt=now;lastLiveLocation=loc;
                js("onLiveLocation","{\"lat\":"+loc.getLatitude()+",\"lng\":"+loc.getLongitude()+",\"accuracy_m\":"+loc.getAccuracy()+"}");
            };
            String provider = liveManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER;
            liveManager.requestLocationUpdates(provider,5000L,15f,liveListener);
            liveCouponsEnabled=true;
            js("onNotice", "주변 쿠폰 탐색을 시작했습니다. 위치 기록은 저장하지 않습니다.");
        } catch (SecurityException|IllegalArgumentException e) {stopLiveLocation();js("onNotice", "위치 권한이나 GPS 설정을 확인하세요.");}
    }
    private void stopLiveLocation() {
        liveCouponsEnabled=false;
        if(liveManager!=null && liveListener!=null) try{liveManager.removeUpdates(liveListener);}catch(Exception ignored){}
        liveListener=null;lastLiveLocation=null;lastLiveSentAt=0;
    }
    @Override protected void onPause() { super.onPause(); stopLiveLocation(); }
    @Override protected void onResume() { super.onResume(); if(view!=null) js("onTrackingStopped", "{}"); }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        view.removeJavascriptInterface("AndroidApp"); view.destroy(); offline.close(); super.onDestroy();
    }
    private static final class CacheStore extends SQLiteOpenHelper {
        CacheStore(Context ctx) { super(ctx,"travel_public_cache.db",null,1); }
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS public_cache(cache_key TEXT PRIMARY KEY,payload TEXT NOT NULL,updated_at INTEGER NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS public_cache"); onCreate(db);
        }
        synchronized void put(String key, String payload) {
            if (payload == null || payload.length()>400000) return;
            try {
                getWritableDatabase().execSQL("INSERT OR REPLACE INTO public_cache(cache_key,payload,updated_at) VALUES(?,?,?)",
                    new Object[]{key,payload,System.currentTimeMillis()});
                getWritableDatabase().execSQL("DELETE FROM public_cache WHERE updated_at < ?", new Object[]{System.currentTimeMillis()-604800000L});
            } catch(Exception ignored) { }
        }
        synchronized String get(String key) {
            try (Cursor c=getReadableDatabase().rawQuery("SELECT payload FROM public_cache WHERE cache_key=? AND updated_at>=?",
                    new String[]{key,Long.toString(System.currentTimeMillis()-604800000L)})){
                return c.moveToFirst()?c.getString(0):null;
            } catch(Exception ex){return null;}
        }
    }

}

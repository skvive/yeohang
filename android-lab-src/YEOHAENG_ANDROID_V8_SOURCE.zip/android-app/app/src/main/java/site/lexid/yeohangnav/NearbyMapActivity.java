package site.lexid.yeohangnav;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Insets;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 여행갈지도: 앱 내부에서 제공하는 인터랙티브 숙소 멀티핀 지도.
 * 지도 캔버스는 Android WebView에서 로컬 자산으로 실행합니다. 진짜 네이티브 지도 SDK도,
 * 실시간 턴바이턴 카카오 Navigation SDK도 아닙니다. 각 목적지 길찾기는 외부 지도 앱에 위임합니다.
 */
public final class NearbyMapActivity extends Activity {
    private static final double GARAK_LAT = 37.493060;
    private static final double GARAK_LNG = 127.118060;
    private static final int GPS_REQUEST = 391;
    private static final String SERVER = "https://yeohang.lexid.site";
    private static final String LOCAL_MAP = "file:///android_asset/nearby-map.html";
    private static final byte[] EMPTY = new byte[0];

    private WebView mapView;
    private boolean ready = false;
    private boolean gpsApproved = false;
    private double lat = GARAK_LAT;
    private double lng = GARAK_LNG;
    private String currentCategory = "all";
    private final AtomicInteger requestSequence = new AtomicInteger(0);
    private String pendingBootstrap = null;

    private static boolean valid(double a, double b) {
        return Double.isFinite(a) && Double.isFinite(b) && a >= 33 && a <= 39.7 && b >= 124 && b <= 132;
    }
    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private static boolean validCategory(String category) {
        return category != null && category.matches("all|hotel|motel|pension|private|resort|guesthouse|hanok|camping|other");
    }
    private void evaluate(String method, String jsonObject) {
        runOnUiThread(() -> {
            if (ready && mapView != null && !isFinishing() && !isDestroyed()) {
                mapView.evaluateJavascript("window.YeoMap && window.YeoMap." + method + "(" + JSONObject.quote(jsonObject) + ");", null);
            }
        });
    }
    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(0xFF092D43);
        getWindow().setNavigationBarColor(0xFF092D43);
        String cat = getIntent().getStringExtra("category");
        currentCategory = validCategory(cat) ? cat : "all";
        double initialLat = getIntent().getDoubleExtra("lat", GARAK_LAT);
        double initialLng = getIntent().getDoubleExtra("lng", GARAK_LNG);
        gpsApproved = getIntent().getBooleanExtra("gpsApproved", false) &&
                hasLocationPermission() && valid(initialLat,initialLng);
        if (gpsApproved) {lat = initialLat; lng = initialLng;}
        mapView = new WebView(this);
        if(Build.VERSION.SDK_INT>=35) {
            getWindow().setDecorFitsSystemWindows(false);
            mapView.setOnApplyWindowInsetsListener((v,insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
                return insets;
            });
        }
        WebSettings settings = mapView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        // OSM tile provider requires identifiable clients and honouring standard HTTP caches.
        settings.setUserAgentString(settings.getUserAgentString() + " YeohangGaljido/8.0 (+https://yeohang.lexid.site)");
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        mapView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                // An explicit attribution tap may open OSM copyright externally.
                if ("https".equals(uri.getScheme()) && "www.openstreetmap.org".equals(uri.getHost()) && "/copyright".equals(uri.getPath())) {
                    openExternal(uri);return true;
                }
                // Reject frame navigation away from the local verified map surface.
                return !LOCAL_MAP.equals(uri.toString());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                String scheme = uri.getScheme(),host=uri.getHost();
                if ("file".equals(scheme) && uri.toString().startsWith("file:///android_asset/")) return null;
                // Interactive viewport tiles only. Source use is subject to OSM's tile policy.
                if ("https".equals(scheme) && "tile.openstreetmap.org".equals(host) &&
                    uri.getPath() != null && uri.getPath().matches("/\\d{1,2}/\\d+/\\d+\\.png")) return null;
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(EMPTY));
            }
            @Override public void onPageFinished(WebView view, String url) {
                if(!LOCAL_MAP.equals(url)) return;
                ready=true;
                JSONObject bootstrap=new JSONObject();
                try {
                    bootstrap.put("category",currentCategory);
                    bootstrap.put("lat",lat);
                    bootstrap.put("lng",lng);
                    bootstrap.put("gpsApproved",gpsApproved);
                    bootstrap.put("radiusKm",5);
                    bootstrap.put("brand","김별의 새로운 대동여지도");
                } catch(Exception ignored) { }
                evaluate("bootstrap", bootstrap.toString());
            }
        });
        mapView.addJavascriptInterface(new NearbyBridge(), "YeoAndroidMap");
        setContentView(mapView);
        mapView.loadUrl(LOCAL_MAP);
    }
    private void sendError(int seq, String message) {
        JSONObject obj=new JSONObject();
        try {obj.put("sequence",seq);obj.put("error",message);}catch(Exception ignored){}
        evaluate("receive",obj.toString());
    }
    private void loadPins(String category) {
        if(!validCategory(category)) category="all";
        currentCategory=category;
        final int seq=requestSequence.incrementAndGet();
        final String selectedCategory=category;
        final double centerLat=lat,centerLng=lng;
        final boolean approved=gpsApproved;
        new Thread(() -> {
            HttpURLConnection conn=null;
            try {
                // GPS queries originate only from foreground explicit permission. No location logging/cache.
                String query="?category="+Uri.encode(selectedCategory)+"&lat="+centerLat+"&lng="+centerLng+
                    "&origin="+(approved?"gps":"default");
                conn=(HttpURLConnection)new URL(SERVER+"/api/map"+query).openConnection();
                conn.setConnectTimeout(9000);
                conn.setReadTimeout(12000);
                conn.setRequestProperty("Accept","application/json");
                int status=conn.getResponseCode();
                if(status<200||status>=300)throw new IllegalStateException("HTTP "+status);
                StringBuilder content=new StringBuilder();
                try(BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream(),StandardCharsets.UTF_8))){
                    String line;
                    while((line=reader.readLine())!=null){
                        content.append(line);
                        if(content.length()>250000)throw new IllegalStateException("데이터 크기 초과");
                    }
                }
                JSONObject data=new JSONObject(content.toString());
                if(!selectedCategory.equals(data.optString("category", "")))throw new IllegalStateException("카테고리 불일치");
                JSONArray raw=data.optJSONArray("pins");
                JSONArray pins=new JSONArray();
                if(raw!=null)for(int i=0;i<Math.min(raw.length(),80);i++){
                    JSONObject p=raw.optJSONObject(i);if(p==null)continue;
                    double d=p.optDouble("distance_km",Double.NaN);
                    double a=p.optDouble("lat",Double.NaN),b=p.optDouble("lng",Double.NaN);
                    if(!valid(a,b)||!Double.isFinite(d)||d<0||d>5.0)continue;
                    if(!"all".equals(selectedCategory)&&!selectedCategory.equals(p.optString("stay_type")))continue;
                    pins.put(p);
                }
                if(seq!=requestSequence.get())return;
                JSONObject output=new JSONObject();
                output.put("sequence",seq);output.put("category",selectedCategory);
                output.put("centerLat",centerLat);output.put("centerLng",centerLng);
                output.put("origin",approved?"gps":"default");output.put("pins",pins);
                output.put("count",pins.length());output.put("radiusKm",5);
                evaluate("receive",output.toString());
            }catch(Exception e){if(seq==requestSequence.get())sendError(seq,"숙소 지도를 불러오지 못했습니다. 연결 상태를 확인하세요.");}
            finally{if(conn!=null)conn.disconnect();}
        },"yeohang-map-query").start();
    }
    private void requestFreshLocation() {
        runOnUiThread(() -> {
            if(!hasLocationPermission()) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION}, GPS_REQUEST);
            }else obtainLocation();
        });
    }
    private void obtainLocation() {
        if(!hasLocationPermission()) {gpsUnavailable();return;}
        try {
            LocationManager mgr=(LocationManager)getSystemService(LOCATION_SERVICE);
            if(mgr==null){gpsUnavailable();return;}
            String provider=mgr.isProviderEnabled(LocationManager.GPS_PROVIDER)?LocationManager.GPS_PROVIDER:
                mgr.isProviderEnabled(LocationManager.NETWORK_PROVIDER)?LocationManager.NETWORK_PROVIDER:null;
            if(provider==null){gpsUnavailable();return;}
            if(Build.VERSION.SDK_INT>=30){
                mgr.getCurrentLocation(provider,null,getMainExecutor(), loc -> applyLocation(loc));
            }else{
                Location l=mgr.getLastKnownLocation(provider);
                if(l!=null && System.currentTimeMillis()-l.getTime()<120000L)applyLocation(l);
                else gpsUnavailable();
            }
        }catch(SecurityException ex){gpsUnavailable();}
    }
    private void applyLocation(Location loc) {
        if(loc==null||!valid(loc.getLatitude(),loc.getLongitude())) {gpsUnavailable();return;}
        lat=loc.getLatitude();lng=loc.getLongitude();gpsApproved=true;
        JSONObject out=new JSONObject();
        try {out.put("lat",lat);out.put("lng",lng);out.put("gpsApproved",true);}catch(Exception ignored){}
        evaluate("locationChanged",out.toString());
        loadPins(currentCategory);
    }
    private void gpsUnavailable() {
        gpsApproved=false;lat=GARAK_LAT;lng=GARAK_LNG;
        evaluate("locationChanged", "{\"lat\":"+GARAK_LAT+",\"lng\":"+GARAK_LNG+",\"gpsApproved\":false}");
        loadPins(currentCategory);
    }
    @Override public void onRequestPermissionsResult(int code,String[] names,int[] results){
        super.onRequestPermissionsResult(code,names,results);
        if(code!=GPS_REQUEST)return;
        if(hasLocationPermission())obtainLocation(); else gpsUnavailable();
    }
    public final class NearbyBridge {
        @JavascriptInterface public void requestCategory(String category){
            runOnUiThread(() -> loadPins(category));
        }
        @JavascriptInterface public void requestGps(){requestFreshLocation();}
        @JavascriptInterface public void resetDefault(){runOnUiThread(NearbyMapActivity.this::gpsUnavailable);}
        @JavascriptInterface public void openDetails(String id){
            if(id==null||!id.matches("[A-Za-z0-9_:-]{1,100}"))return;
            runOnUiThread(() -> openExternal(Uri.parse(SERVER+"/stay/"+Uri.encode(id))));
        }
        @JavascriptInterface public void navigate(double destLat,double destLng){
            if(!valid(destLat,destLng))return;
            Uri fallback=Uri.parse("https://www.google.com/maps/dir/").buildUpon()
                .appendQueryParameter("api","1")
                .appendQueryParameter("destination",destLat+","+destLng)
                .appendQueryParameter("travelmode","driving").build();
            runOnUiThread(() -> {
                // Kakao-enabled build variants delegate actual guidance to the official Kakao Navi app.
                if (BuildConfig.KAKAO_LINK_ENABLED && !BuildConfig.KAKAO_NATIVE_APP_KEY.isEmpty()) {
                    try {
                        Class<?> cls=Class.forName("site.lexid.yeohangnav.KakaoLaunchActivity");
                        Intent intent=new Intent(NearbyMapActivity.this,cls);
                        intent.putExtra("lat",destLat);intent.putExtra("lng",destLng);
                        intent.putExtra("label","여행갈지도 선택 숙소");
                        startActivity(intent);return;
                    }catch(Exception ignored){}
                }
                openExternal(fallback);
            });
        }
        @JavascriptInterface public void closeMap(){runOnUiThread(NearbyMapActivity.this::finish);}
    }
    private void openExternal(Uri uri){
        try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}
        catch(ActivityNotFoundException e){Toast.makeText(this,"지도 앱을 찾을 수 없습니다.",Toast.LENGTH_SHORT).show();}
    }
    @Override protected void onDestroy(){
        requestSequence.incrementAndGet();
        if(mapView!=null){mapView.removeJavascriptInterface("YeoAndroidMap");mapView.destroy();mapView=null;}
        super.onDestroy();
    }
}

package site.lexid.yeohangnav;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;
import com.google.android.libraries.navigation.NavigationApi;
import com.google.android.libraries.navigation.NavigationFragment;
import com.google.android.libraries.navigation.Navigator;
import com.google.android.libraries.navigation.Waypoint;
import com.google.android.libraries.navigation.RoutingOptions;
import com.google.android.libraries.navigation.AudioGuidanceSettings;
import com.google.android.libraries.navigation.ListenableResultFuture;

/** Only built in sdkNav flavor. Requires approved Google Cloud navigation API key.
 * Never automatically starts driving route without explicit user action.
 */
public final class NavigationActivity extends Activity {
    private Navigator navigator;
    private NavigationFragment fragment;
    private double latitude, longitude;
    private String destinationName;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        latitude = getIntent().getDoubleExtra("lat", Double.NaN);
        longitude = getIntent().getDoubleExtra("lng", Double.NaN);
        destinationName = getIntent().getStringExtra("label");
        if (!Double.isFinite(latitude) || !Double.isFinite(longitude) ||
            latitude < 33 || latitude > 39.7 || longitude < 124 || longitude > 132) {
            fail("유효하지 않은 목적지입니다."); return;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 409);
            return;
        }
        initialize();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 409) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) initialize();
            else fail("실시간 길안내에는 위치 권한이 필요합니다.");
        }
    }
    private void initialize() {
        fragment = NavigationFragment.newInstance();
        getFragmentManager().beginTransaction().replace(android.R.id.content, fragment).commitNow();
        NavigationApi.getNavigator(this, new NavigationApi.NavigatorListener() {
            @Override public void onNavigatorReady(Navigator nav) {
                navigator = nav;
                Waypoint dest;
                try {
                    dest = Waypoint.builder().setLatLng(latitude, longitude).setTitle(destinationName == null ? "목적지" : destinationName).build();
                } catch (Exception err) { fail("목적지를 설정할 수 없습니다."); return; }
                RoutingOptions route = new RoutingOptions();
                route.travelMode(RoutingOptions.TravelMode.DRIVING);
                nav.setDestination(dest, route).setOnResultListener(code -> runOnUiThread(() -> {
                    if (code == Navigator.RouteStatus.OK) {
                        nav.setAudioGuidanceSettings(AudioGuidanceSettings.builder()
                             .setGuidanceMode(AudioGuidanceSettings.GuidanceMode.VOICE_ALERTS_AND_GUIDANCE).build());
                        nav.startGuidance();
                    } else fail("경로 안내를 시작하지 못했습니다: " + code);
                }));
            }
            @Override public void onError(@NavigationApi.ErrorCode int errorCode) {
                fail("Google Navigation SDK 사용 불가: " + errorCode);
            }
        });
    }
    private void fail(String text) { runOnUiThread(() -> {Toast.makeText(this,text,Toast.LENGTH_LONG).show();finish();}); }
    @Override public void onDestroy() {
        if (navigator != null) { navigator.stopGuidance(); navigator.clearDestinations(); }
        super.onDestroy();
    }
}

﻿@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ==============================================================
echo   YEOHAENG GALJIDO - Android test APK build (mapsLinkDebug)
echo ==============================================================
where java >nul 2>&1
if errorlevel 1 (
  echo ERROR: JDK 17 or newer is required.
  echo Install Android Studio: https://developer.android.com/studio
  exit /b 3
)
if not exist "%LOCALAPPDATA%\Android\Sdk\platforms\android-36" if not defined ANDROID_HOME (
  echo NOTICE: Android SDK API 36 was not found in default SDK directory.
  echo Install API 36 in Android Studio SDK Manager, or set ANDROID_HOME.
)
if exist "gradle\wrapper\gradle-wrapper.jar" (
  call gradlew.bat --no-daemon :app:assembleMapsLinkDebug
) else (
  where gradle >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Gradle command not found, wrapper JAR absent.
    echo Install Gradle 8.13 and add to PATH, then retry.
    echo Docs: https://gradle.org/install/
    echo You can run: gradle wrapper --gradle-version 8.13
    exit /b 4
  )
  call gradle --no-daemon :app:assembleMapsLinkDebug
)
if errorlevel 1 (echo BUILD FAILED & exit /b 5)
set "APK=app\build\outputs\apk\mapsLink\debug\app-mapsLink-debug.apk"
if not exist "%APK%" (echo ERROR: APK not found at %APK% & exit /b 6)
copy /y "%APK%" "%~dp0..\YEOHAENG_GALJIDO_TEST_INSTALL.apk" >nul
echo.
echo SUCCESS: %~dp0..\YEOHAENG_GALJIDO_TEST_INSTALL.apk
echo This is a DEBUG APK, NOT a Play-ready signed AAB.
endlocal

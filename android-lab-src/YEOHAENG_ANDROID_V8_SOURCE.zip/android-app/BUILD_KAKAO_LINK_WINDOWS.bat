@echo off
setlocal
cd /d "%~dp0"
if "%KAKAO_NATIVE_APP_KEY%"=="" (
  echo KAKAO_NATIVE_APP_KEY is not set. Kakao Navi will fall back to map app.
)
where gradle >nul 2>&1
if errorlevel 1 (
  if not exist "gradle\wrapper\gradle-wrapper.jar" (
    echo Gradle is not available and the original ZIP has no wrapper JAR.
    echo Open android-app in Android Studio, install SDK 36 and configure Gradle, then run assembleKakaoLinkDebug.
    exit /b 2
  )
  call gradlew.bat :app:assembleKakaoLinkDebug
) else (
  call gradle :app:assembleKakaoLinkDebug
)
if errorlevel 1 exit /b 1
echo APK should be in app\build\outputs\apk\kakaoLink\debug\
endlocal
